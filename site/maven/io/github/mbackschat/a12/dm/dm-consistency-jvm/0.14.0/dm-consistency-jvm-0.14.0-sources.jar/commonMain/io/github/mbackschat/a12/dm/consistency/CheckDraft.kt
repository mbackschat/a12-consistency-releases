package io.github.mbackschat.a12.dm.consistency

import kotlinx.serialization.json.JsonObject

/**
 * Check DSL text an editor has typed but not saved, in the model it belongs to.
 *
 * **The draft is applied to the FACT BASE, not to the source, and that is the point.** Text being typed is
 * not in any model yet; an editor that wrote it into the source to find out would have to undo the write on
 * every keystroke, and a consumer that checked the text alone would lose the model context every reference in
 * it resolves against. So the declaration at [at] is re-declared in the prepared fact base with [member]
 * carrying [text], and that fact base is checked.
 *
 * **The answer is attributed, exactly as [checkEdit] attributes a saved edit.** A draft's verdict may not
 * absorb its neighbours' defects: an author typing into a model that is already broken elsewhere would
 * otherwise be told their draft is invalid, which is the over-rejection this module forbids. The neighbours'
 * findings ride along on [EditReport.baseline] as a disclosure.
 *
 * **Half-typed text is INCOMPLETE, not invalid** — the state an editor is in most of the time. Nothing here
 * promotes that to a rejection. A12's class for it is `MVK_INCOMPLETE_INPUT` where the text ends A12's input,
 * and `MVK_UNEXPECTED_TOKEN` raised past the typed text in a computation member A12 reads on after
 * ([followedInGeneratedText]); both are demoted.
 *
 * One preparation serves both sides: the baseline and the drafted fact base are the same prepared model with
 * one declaration replaced, so a keystroke costs one admission and one preparation rather than two.
 *
 * @param at the declaration's path, as a report names it.
 * @param member the DSL member being typed, spelled as a report names it — `errorCondition`,
 *     `commonPrecondition`, `computationAlternatives[0].precondition`, `computationAlternatives[0].operation`.
 * @return the draft's own attribution. A draft that could not be applied at all — an unreadable source, a
 *     path this model does not declare, a member this declaration cannot carry — attributes NOTHING and says
 *     why as a [CoverageGap], rather than raising or guessing.
 */
fun checkDraft(source: ModelSource, at: String, member: String, text: String): EditReport {
    val admitted = admit(source) as? Admission.Admitted
        ?: check(source).let { report ->
            return refusedDraft(report, CoverageGap(
                null,
                "the source could not be read, so there is no model for this draft to be checked in",
            ))
        }
    val prepared = prepare(admitted, providers = emptyMap())
    val baseline = checkPrepared(prepared, admitted.modelId, inherited = emptyList())
    return when (val drafted = prepared.draftedWith(at, member, text)) {
        is Drafted.Refused -> refusedDraft(baseline, drafted.gap)
        is Drafted.Applied -> asDraftVerdict(
            attribute(baseline, checkPrepared(drafted.prepared, admitted.modelId, inherited = emptyList())),
            drafted,
        )
    }
}

/**
 * The code A12 gives text that simply ran out at the end of its input — one of the two classes a DRAFT must
 * not be condemned for; [Drafted.Applied.ranOut] names the other.
 *
 * Deliberately these and no others. An unbalanced parenthesis is `MVK_EXPECTED_TOKEN_NOT_FOUND`, a
 * separately measured class (the plan's 12-input parser probe), and widening this set to "anything that looks
 * unfinished" would be a refusal-shaped decision with no measured basis. If another code earns a place here
 * it arrives with its own measurement.
 */
private const val INCOMPLETE_INPUT = "MVK_INCOMPLETE_INPUT"

/**
 * Turn an attribution into a DRAFT's verdict: incompleteness is reported, and stops condemning the draft.
 *
 * **This exists because the contract was advertised four times and enforced nowhere.** [checkDraft]'s own
 * KDoc says in bold that half-typed text "is INCOMPLETE, not invalid" and that "nothing here promotes that to
 * a rejection"; `CheckDraftTest.anIncompleteDraftIsNotBlamedOnTheAuthorAsAnInvalidOne` says it in its NAME
 * while asserting only the code; and [CONSISTENCY-API] published it to consumers. Measured 2026-09-18 through
 * the packed package, a draft ending in `And` returned `status: INVALID` with the finding at
 * `justifiesRejection: true` — the exact over-rejection all four statements forbid, on every keystroke an
 * author spends mid-expression.
 *
 * **The demotion is the SEVERITY, not the category, and that distinction is the honest one.** The code is
 * A12's and the category says so; what changes is the consequence, because a draft is not a save. A12 would
 * indeed reject this text if it were stored, which is why [checkEdit] — whose subject IS stored text — gets
 * no such treatment and must not: an edit that saves unfinished text is invalid, and saying otherwise would
 * be the mirror over-acceptance.
 *
 * Applying it here rather than in each caller is deliberate: the stateless [checkDraft] and
 * [ConsistencySnapshot.draft] build their input differently and would otherwise be two arms of one contract,
 * which is how this estate's paired arms have diverged before.
 */
internal fun asDraftVerdict(attributed: EditReport, drafted: Drafted.Applied): EditReport {
    val introduced = attributed.introduced.map { finding ->
        if (drafted.ranOut(finding) && finding.severity == FindingSeverity.ERROR) {
            finding.copy(severity = FindingSeverity.WARNING)
        } else {
            finding
        }
    }
    // Recomputed from the demoted findings rather than patched, so the status cannot disagree with the
    // `justifiesRejection` a consumer is told to read instead of it.
    return attributed.copy(introduced = introduced, status = statusOf(introduced))
}

/** Either the fact base with the draft in it, or the reason the draft was not applied. */
internal sealed interface Drafted {

    /**
     * @param followed whether A12 reads on past the drafted member ([followedInGeneratedText]), which decides
     *     the class half-typed text draws there.
     */
    data class Applied(
        val prepared: PreparedModel,
        val member: String,
        val text: String,
        val followed: Boolean,
    ) : Drafted {

        /**
         * Whether [finding] is A12's class for this draft simply running out.
         *
         * Where A12's input ends with the member that is `MVK_INCOMPLETE_INPUT`. Where A12 reads on, the same
         * text meets the `)` A12 added and draws `MVK_UNEXPECTED_TOKEN` raised past everything typed
         * ([KERNEL-FINDINGS KF471]) — so the token class counts only at or beyond the draft's own end, and a
         * wrong token the author actually typed, which sits inside the text, is still condemned.
         */
        fun ranOut(finding: Finding): Boolean = when (finding.code) {
            INCOMPLETE_INPUT -> true
            UNEXPECTED_TOKEN -> followed && finding.span?.let { it.member == member && it.start >= text.length } == true
            else -> false
        }
    }

    data class Refused(val gap: CoverageGap) : Drafted
}

/**
 * The same fact base with one declaration's DSL member replaced, or why it could not be.
 *
 * One function rather than an apply and a separate explain, because the two would have to agree about which
 * inputs are admissible — and the caller that got one without the other is where they would stop agreeing.
 *
 * The element's whole declaration is rebuilt rather than its body mutated, because `body` is DERIVED from
 * `declaration[kind]`: writing into a body object would leave the declaration every other reader sees
 * unchanged, which is the silent half of that indirection.
 */
internal fun PreparedModel.draftedWith(at: String, member: String, text: String): Drafted {
    val element = elements.firstOrNull { it.path == at }
    val body = element?.body
    if (element == null || body == null) {
        return Drafted.Refused(CoverageGap(
            at,
            "this model declares no rule or computation there, so the draft has nothing to be typed into",
        ))
    }
    val draftable = draftableMembers(element.kind, body)
    if (member !in draftable) {
        return Drafted.Refused(CoverageGap(
            at,
            "a `${element.kind}` carries no DSL member `$member`; this one can carry " +
                draftable.joinToString(", ") { "`$it`" }.ifEmpty { "no DSL text at all" },
        ))
    }
    val drafted = replaceConditionText(body, member, text)
        ?: return Drafted.Refused(CoverageGap(
            at,
            "`$member` could not be replaced in this declaration, so the draft was not analysed",
        ))
    val redeclared = element.copy(declaration = JsonObject(element.declaration + (element.kind to drafted)))
    return Drafted.Applied(
        copy(elements = elements.map { if (it.path == element.path) redeclared else it }),
        member,
        text,
        followedInGeneratedText(element.kind, drafted, member),
    )
}

/**
 * A draft that was not analysed: nothing attributed, and the reason stated.
 *
 * `edited` repeats the baseline deliberately. The alternative would be to publish no edited report at all,
 * and a consumer reading `edited` as "the model with my draft in it" would then have to distinguish absent
 * from empty — where what actually happened is that the model was checked and the draft never reached it.
 */
internal fun refusedDraft(baseline: ConsistencyReport, gap: CoverageGap) = EditReport(
    baseline = baseline,
    edited = baseline,
    introduced = emptyList(),
    resolved = emptyList(),
    status = ConsistencyStatus.Inconclusive,
    gaps = listOf(gap),
)
