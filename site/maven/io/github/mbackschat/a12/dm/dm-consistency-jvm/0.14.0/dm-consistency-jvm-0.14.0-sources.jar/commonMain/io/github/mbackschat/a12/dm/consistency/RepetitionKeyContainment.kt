package io.github.mbackschat.a12.dm.consistency


import io.github.mbackschat.a12.dm.consistency.syntax.ConditionCall
import io.github.mbackschat.a12.dm.consistency.syntax.OPERATOR_SPELLINGS
import io.github.mbackschat.a12.dm.consistency.syntax.OperatorId

/**
 * Where a `RepetitionNotUnique` KEY has to sit relative to the scope that bounds it.
 *
 * `CheckWiederholungBedingungImpl.check` has two arms and the scope decides which: with an `@From` clause
 * every key's parent path must start with the scope's, and without one the keys' repeatable groups must lie
 * on a single hierarchy path and every key must sit inside the rule's own group
 * ([KERNEL-FINDINGS KF375], `rulekit.validate.laws.RepetitionNotUniqueFromScopeLawsTest`,
 * `…RepetitionNotUniqueKeyPathLawsTest`).
 *
 * | the arm, and what the key does | class |
 * |---|---|
 * | `@From`: the key sits outside the scope | `MVK_NOT_IN_GROUP` |
 * | no `@From`: two keys' repetitions lie on parallel branches | `MVK_NOT_IN_SAME_PATH` |
 * | no `@From`: a key sits outside the rule's own group | `MVK_NOT_IN_RULEGROUP` |
 *
 * **All three are barely reachable, and what makes them reachable is INDEX-KEYING rather than containment.**
 * Two repeatable groups on parallel branches iterate jointly only when they declare the same index field;
 * without that A12 refuses the pairing at the wildcard gate and draws `MVK_NO_WILDCARD` long before it asks
 * where anything sits. So every parallel shape here is judged only on an index-keyed pair, and the
 * index-free one is left to [operandScopeContributions], which owns that class. The `@From` arm carries
 * the same condition against the SCOPE rather than against another key. A key with no repetition at all
 * crosses no level the wildcard gate could refuse, so it draws the class outright ([KERNEL-FINDINGS KF612]).
 *
 * **The rule-group gate asks only where the key list is sound**, every key read without a wildcard class
 * ([repetitionKeyListIsSound]). A key outside the rule group then draws `MVK_NOT_IN_RULEGROUP` whether it
 * crosses no repetition at all or one iterated jointly with the rule's own — both measured
 * (`adapter.laws.CheckerRepetitionNotUniqueGateAgreementTest`). Taking ANY repetition of the outsider's as
 * the wildcard gate's is the trap: the rule's iteration reaches a jointly iterated one.
 *
 * **Silent once the rule group CONTAINS every key**, where [repetitionKeyPlacementFindings] takes over with
 * `MVK_REPEATABLE_GROUP_MISSING`: the two families partition the no-`@From` arm at exactly the gate A12
 * partitions it, containment first and the repetition demand after.
 *
 * **Silent on every key-list and scope defect**, which A12 gates ahead of containment: the key list's own
 * classes are [repetitionKeyListFindings]', and a scope naming a field draws `MVK_NO_FIELDS_ALLOWED` and a
 * non-repeatable one `MVK_GROUP_NOT_REPEATABLE`, both [repetitionScopeContributions]'.
 *
 * **Rules only**, for the reason its two siblings are: A12's calculation module refuses the operator in a
 * computation outright ([KERNEL-FINDINGS KF333]), so a computation carrying one has a different defect.
 */
internal fun TrackedFactBase.repetitionContainmentContributions(element: TrackedDeclaration): List<ConditionFinding> {
    if (element.declaredKind != DeclaredKind.RULE) return emptyList()
    val keywords = OPERATOR_SPELLINGS[conditionLanguage] ?: return emptyList()
    val spelling = keywords[OperatorId.REPETITION_NOT_UNIQUE] ?: return emptyList()
    val scopeKeyword = keywords[OperatorId.FROM_SCOPE] ?: return emptyList()
    val group = element.path.substringBeforeLast('/')
    return callContributions(element) { member, call ->
        if (call.operator != spelling) return@callContributions null
        containmentDefect(call, scopeKeyword, group, element)?.let { containmentFinding(it, call, element, member) }
    }
}

private data class ContainmentDefect(val code: String, val key: String, val bound: String)

/**
 * The first containment gate this call fails, in A12's own order.
 *
 * The key list is taken whole or not at all: one that does not pass its own gates is answered by an earlier
 * class, and guessing which would attach a containment fix to a different defect.
 */
private fun TrackedFactBase.containmentDefect(
    call: ConditionCall,
    scopeKeyword: String,
    declaringGroup: String,
    element: TrackedDeclaration,
): ContainmentDefect? {
    if (!repetitionKeyListIsSound(call, declaringGroup, element)) {
        return null
    }
    val scopeText = call.operands.firstNotNullOfOrNull { operand -> scopeTextOf(operand, scopeKeyword) }
    // A scope carrying more than a path, such as an index, meets its own gates first ([repetitionScopeContributions]).
    val scopeSpelling = scopeText?.let { it.bare ?: return null }
    val written = call.operands.map { it.base ?: return null }
    val keys = written.mapNotNull {
        (resolveEntity(declaringGroup, it, element.origin) as? Reference.Resolved)?.path
    }
    if (keys.size != written.size) {
        return null
    }
    val scope = scopeSpelling?.let {
        repeatableGroupAt((resolveEntity(declaringGroup, it, element.origin) as? Reference.Resolved)?.path)
            ?: return null
    }
    return if (scope != null) outsideScope(keys, scope) else withoutScope(keys, declaringGroup)
}

/**
 * The `@From` arm: every key's parent has to sit under the scope.
 *
 * A key outside it in a repetition of its own is only ASKED where the two branches iterate jointly; otherwise
 * the wildcard gate has already answered, which is the measured difference between an index-keyed pair and an
 * index-free one. A key in no repetition meets no wildcard gate and is asked outright.
 */
private fun TrackedFactBase.outsideScope(keys: List<String>, scope: TrackedDeclaration): ContainmentDefect? {
    val outside = keys.firstOrNull { !parentOf(it).startsWith("${scope.path}/") } ?: return null
    val repetition = lowestRepetitionOf(outside)
    return if (repetition == null || iteratesJointlyWith(repetition, scope)) {
        ContainmentDefect("MVK_NOT_IN_GROUP", outside, scope.path)
    } else {
        null
    }
}

/**
 * The no-`@From` arm, in source order: the repetitions must chain, then every key must sit in the rule group.
 *
 * The chain test walks the keys in authored order and keeps the longest path seen, exactly as A12 does, so
 * the key REPORTED is the first one that cannot extend it rather than the pair that disagrees.
 */
private fun TrackedFactBase.withoutScope(keys: List<String>, declaringGroup: String): ContainmentDefect? {
    var chain: TrackedDeclaration? = null
    keys.forEach { key ->
        val repetition = lowestRepetitionOf(key) ?: return@forEach
        val held = chain
        if (held == null) {
            chain = repetition
            return@forEach
        }
        val nested = repetition.path.startsWith("${held.path}/") || held.path.startsWith("${repetition.path}/")
        if (!nested && repetition.path != held.path) {
            return if (iteratesJointlyWith(repetition, held)) {
                ContainmentDefect("MVK_NOT_IN_SAME_PATH", key, held.path)
            } else {
                null
            }
        }
        if (repetition.path.length > held.path.length) {
            chain = repetition
        }
    }
    // Every key read cleanly, so an outsider in a repetition of its own is one the rule's iteration reaches.
    val outside = keys.firstOrNull { !parentOf(it).startsWith("$declaringGroup/") } ?: return null
    return ContainmentDefect("MVK_NOT_IN_RULEGROUP", outside, declaringGroup)
}

/** The parent path of [path], with the trailing separator A12's own comparison carries. */
private fun parentOf(path: String): String = "${path.substringBeforeLast('/', missingDelimiterValue = "")}/"

/** The innermost repeatable group [path] lies under, which is the level A12 compares. */
private fun TrackedFactBase.lowestRepetitionOf(path: String): TrackedDeclaration? = repeatableGroups()
    .filter { path.startsWith("${it.path}/") }
    .maxByOrNull { it.path.length }

private fun TrackedFactBase.repeatableGroupAt(path: String?): TrackedDeclaration? =
    repeatableGroups().firstOrNull { it.path == path }

/**
 * Whether two repeatable groups A12 would otherwise refuse to pair iterate JOINTLY — the same declared index
 * field name on both, which is what makes their repetitions correspond.
 *
 * Absent that, the pair draws `MVK_NO_WILDCARD` before any containment question, so this predicate is the
 * whole reachability of the three classes above rather than a refinement of them.
 */
private fun iteratesJointlyWith(one: TrackedDeclaration?, other: TrackedDeclaration): Boolean {
    val name = indexFieldNameOf(one ?: return false) ?: return false
    return name == indexFieldNameOf(other)
}

private fun containmentFinding(
    defect: ContainmentDefect,
    call: ConditionCall,
    element: TrackedDeclaration,
    member: String,
): Finding = Finding(
    FindingCategory.A12_CONSTRAINT,
    FindingSeverity.ERROR,
    defect.code,
    if (defect.code == "MVK_NOT_IN_SAME_PATH") {
        "this $member asks `${call.operator}` about `${defect.key}`, whose repetition lies on a branch " +
            "PARALLEL to `${defect.bound}` — the operator compares repetitions of one branch, so the keys " +
            "have to sit on a single path through the model"
    } else {
        "this $member asks `${call.operator}` about `${defect.key}`, which sits outside `${defect.bound}` " +
            "— every key has to sit inside the group that bounds the comparison"
    },
    element.path,
    call.spanIn(member),
)
