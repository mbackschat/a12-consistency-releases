package io.github.mbackschat.a12.dm.consistency

import io.github.mbackschat.a12.dm.consistency.syntax.ConditionCall
import io.github.mbackschat.a12.dm.consistency.syntax.OPERATOR_SPELLINGS
import io.github.mbackschat.a12.dm.consistency.syntax.OperatorId

/**
 * What KIND of declaration each FIELD-LIST operation admits in the entity list it shares with the others.
 *
 * `CheckFeldListenOpImpl.check` is one method whose body is a switch on the OPERATOR token, run over a list
 * two shared gates have already accepted — so the class a model draws is decided by the caller and not by
 * the list ([KERNEL-FINDINGS KF391], `rulekit.validate.laws.FieldListOperandKindLawsTest`). A fifth carrier
 * lives in a DIFFERENT kernel method, `CheckFeldListenAnzahlOpImpl.check`, and is here rather than in its
 * own family because it asks this family's question with this family's pre-emptions — the two never share a
 * carrier, so neither can report the other's class ([KERNEL-FINDINGS KF399],
 * `rulekit.validate.laws.DistinctValueOperandKindLawsTest`).
 *
 * | the operator | what it demands of every expanded field | otherwise |
 * |---|---|---|
 * | `FirstFilledValue` | not a Confirm declaration | `MVK_NO_BOOLY_ALLOWED` |
 * | …and then | the first field's type | `MVK_VARYING_TYPES_NOT_ALLOWED` |
 * | `Sum` | a Number declaration | `MVK_NO_NUMBER` |
 * | `MaxValue`, `MinValue`, behind a non-temporal LEADER | a Number declaration | `MVK_NOT_SORTABLE` |
 * | `NumberOfDifferentValues`, behind a text/custom/enum LEADER | one of those three | `MVK_STRING_ENUM_AND_NON_STRING_ENUM` |
 * | …and then | value validation not waived | `MVK_INVALID_RAW_TYPE` |
 * | `NumberOfDifferentValues`, behind a NUMBER leader | a Number declaration | `MVK_NUMBER_AND_NON_NUMBER` |
 * | `NumberOfDifferentValues`, behind a leader no arm claims | — | `MVK_ONLY_STRING_ENUM_NUMBER_CMP_DATE_ALLOWED` |
 *
 * **The confirm gate is named for a kind it does not name.** `checkNoBoolY` tests `FieldUtils.isYes`, which
 * is `IYesType` alone; `IYesNoType` is a sibling interface rather than a subtype, so a BOOLEAN declaration
 * clears the gate and only a CONFIRM one is refused. Reading the code as "no boolean kinds" is wrong in
 * exactly that cell, and the grid measures both.
 *
 * **One Confirm anywhere in the list refuses it**, in any position and whatever the other operands are,
 * because the walk runs ahead of the type-matching gate rather than inside it.
 *
 * **The extrema's LEADER decides which arm judges the list**, which is why they carry two classes rather
 * than one: a temporal leader hands the list to [OperationAnalysis] and its component-set
 * comparison, and everything else takes the flat numeric question here. A leader whose declared type this
 * reader cannot place leaves the call unjudged rather than guessing the arm.
 *
 * **`NumberOfDifferentValues` takes the same leader mechanism and three of its four arms differ from the
 * extrema's**, which is why it is a table rather than a shared branch. Its string arm FOLDS custom and
 * enumeration in with text where the extrema refuse both; its leader is read off the first EXPANDED field,
 * so a group leader is its own first member; and a leader no arm claims — Boolean, Confirm or DateRange —
 * has a class of its OWN rather than falling into the numeric one. That last row is the one a reader
 * assembling arms from the codes' names would miss, and all three unclaimed leaders are measured.
 *
 * **Its value-validation gate runs over the whole list AFTER the kind walk**, so a kind defect later in the
 * list than a waiving field still answers first — measured, and the reason the two walks are sequential.
 *
 * **Silent wherever a gate ahead of the switch answers instead** — the shared duplicate and root-group
 * pre-gates ([entityListPreGateAnswers]) and this construct's arity gate, a lone unstarred field, which is
 * `MVK_PARAMSIZE_INVALIDN`. All five carriers take that same arity gate. Naming a kind class on any of those
 * would be the wrong class on a correct rejection.
 *
 * **`NumberOfDifferentValues` meets a SIXTH gate the other four never do, and it is another family's.**
 * `checkNoCategories` is the first statement of its method, ahead of the reference list being built, so an
 * Enumeration's category anywhere in its list is `MVK_CATEGORY_NOT_ALLOWED` whatever else is wrong with it —
 * measured, on a list that also carries a duplicate. [entityListCategoryFindings] reports it for every carrier
 * that calls the gate; the shared operand reducer declines a categorized operand, so this family never sees
 * such a call.
 *
 * **`FirstFilledValue` types its list as the FIRST expanded field and asks every later one to match it**
 * ([KERNEL-FINDINGS KF391], `adapter.laws.CheckerFirstFilledValueTypeAgreementTest`). Matching is one base type,
 * an Enumeration and a custom type counting as text, and for a date-bearing kind or a date range also the same
 * declared format; the number's fraction digits play no part. **Two Booleans always match**, though A12's type
 * comparison asks for equal stored values: a Boolean declaring its own values is admitted beside a default one
 * and beside one declaring others. A group operand is its fields, so a mixed group is refused by itself.
 *
 * **`SumOfProducts` is not a carrier**, though it takes the same numeric arm: six of its own gates run
 * before it, and each is a class this family would have to answer for to avoid naming the numeric one on a
 * model A12 refuses for a parallel-list defect. [sumOfProductsOperandFindings] owns that operator.
 *
 * **A TypeDef or Unspecified declaration is skipped rather than judged**, because its effective type is a
 * definition body this checker declares as a coverage gap — a number-based typedef is admitted by every arm
 * here, measured, so refusing one would be an over-rejection. The walk continues past it: a later field's
 * class is the same class A12 would report at the typedef, so only the field a message names can differ.
 */
internal fun TrackedFactBase.fieldListOperationOperandFindings(): List<Finding> = declarations().flatMap { element ->
    fieldListOperationContributions(element).map { it.finding }
}

internal fun TrackedFactBase.fieldListOperationContributions(
    element: TrackedDeclaration,
    execution: ConditionExecution? = conditionExecution(element),
): List<ConditionFinding> {
    val keywords = OPERATOR_SPELLINGS[conditionLanguage] ?: return emptyList()
    val arms = ARM_OF.mapNotNull { (id, arm) -> keywords[id]?.let { it to arm } }.toMap()
    if (arms.isEmpty()) {
        return emptyList()
    }
    val group = element.path.substringBeforeLast('/', missingDelimiterValue = "")
    return callContributions(element, execution) { member, call ->
        val arm = arms[call.operator] ?: return@callContributions null
        operandDefect(call, arm, group, element)?.let { finding(it, call, element, member) }
    }
}

/** One arm of A12's switch on the operator — which question it asks of the list it was handed. */
private enum class FieldListArm {
    NO_CONFIRM,
    ALL_NUMBERS,
    SORTABLE,
    DISTINCT,
}

private val ARM_OF = mapOf(
    OperatorId.FIRST_FILLED_VALUE to FieldListArm.NO_CONFIRM,
    OperatorId.SUM to FieldListArm.ALL_NUMBERS,
    OperatorId.MAX_VALUE to FieldListArm.SORTABLE,
    OperatorId.MIN_VALUE to FieldListArm.SORTABLE,
    OperatorId.NUMBER_OF_DIFFERENT_VALUES to FieldListArm.DISTINCT,
)


/** The declarations `NumberOfDifferentValues`' leader sends down the string arm, which folds all three. */
private val STRING_LIKE_LEADERS = setOf(FieldType.STRING, FieldType.CUSTOM_FIELD, FieldType.ENUMERATION)

/** The leaders NO arm claims, each measured: the else branch has a class of its own. */
private val UNCLAIMED_LEADERS = setOf(FieldType.BOOLEAN, FieldType.CONFIRM, FieldType.DATE_RANGE)

/** The declarations this reader is CERTAIN `isLikeString || isEnum` refuses, every member measured. */
private val PLAINLY_NON_STRING_LIKE_TYPES =
    setOf(FieldType.NUMBER, FieldType.BOOLEAN, FieldType.CONFIRM, FieldType.DATE_RANGE) + TEMPORAL_DECLARED_TYPES

/** What one arm's walk landed on: the class, the field that drew it, and what the operator wanted. */
private class FieldListDefect(val code: String, val demand: String, val field: TrackedDeclaration)

/** The first defect this arm finds, or null where it finds none and where it may not judge. */
private fun TrackedFactBase.operandDefect(
    call: ConditionCall,
    arm: FieldListArm,
    declaringGroup: String,
    element: TrackedDeclaration,
): FieldListDefect? {
    // A filtered operand is its base: A12 reads the whole spec, body included, before this switch, and a body
    // defect closes at an earlier site (KERNEL-FINDINGS KF612).
    val filter = OPERATOR_SPELLINGS[conditionLanguage]?.get(OperatorId.HAVING)
    val reads = call.operands.map { operand ->
        operandReferenceIn(operand.text, declaringGroup, element, call.inAFilterBody) {
            (operand.path ?: operand.base?.takeIf { operand.clauses.all { it.keyword == filter } })?.let { OperandReference(it) }
        } ?: return null
    }
    val targets = addressedTargetsOf(reads, declaringGroup, element, call.inAFilterBody) ?: return null
    if (preEmptedBeforeTheSwitch(reads, targets)) {
        return null
    }
    val fields = targets.flatMap { target ->
        val declared = declarationAt(target) ?: return null
        fieldsUnder(declared) ?: return null
    }
    if (fields.isEmpty()) {
        return null
    }
    return when (arm) {
        FieldListArm.NO_CONFIRM -> fields.firstOrNull { effectiveFieldType(it) == FieldType.CONFIRM }
            ?.let { FieldListDefect("MVK_NO_BOOLY_ALLOWED", "takes no confirm declaration in its list", it) }
            ?: varyingTypeDefect(fields)
        FieldListArm.ALL_NUMBERS -> fields.firstOrNull { effectiveFieldType(it) in PLAINLY_NON_NUMBER_TYPES }
            ?.let {
                FieldListDefect("MVK_NO_NUMBER", "adds up its list, so every field in it must be a number", it)
            }
        FieldListArm.SORTABLE ->
            // The leader picks the arm, so an unplaceable or temporal one is not this family's to judge.
            if (effectiveFieldType(fields.first()).let { it == null || it in TEMPORAL_DECLARED_TYPES }) {
                null
            } else {
                fields.firstOrNull { effectiveFieldType(it) in PLAINLY_NON_NUMBER_TYPES }?.let {
                    FieldListDefect(
                        "MVK_NOT_SORTABLE",
                        "orders its list, and a list led by a non-date must be all numbers",
                        it,
                    )
                }
            }
        FieldListArm.DISTINCT -> distinctDefect(fields)
    }
}

/**
 * The first field that does not match the list's type, which is its FIRST field's, or null where all match.
 *
 * A field whose type this reader does not place is skipped, as every arm here skips one; an unplaceable FIRST
 * field leaves the list untyped and so unjudged.
 */
private fun TrackedFactBase.varyingTypeDefect(fields: List<TrackedDeclaration>): FieldListDefect? {
    val first = fields.first()
    val listType = matchedTypeOf(first) ?: return null
    return fields.drop(1).firstOrNull { field -> matchedTypeOf(field)?.let { it != listType } == true }?.let {
        FieldListDefect(
            "MVK_VARYING_TYPES_NOT_ALLOWED",
            "takes its type from its first field, `${first.path}`, and every later field must match it",
            it,
        )
    }
}

/** What A12's type match reads of one field: the base type, and the format a temporal one declares. */
private data class MatchedType(val base: MatchedBase, val format: String? = null)

private enum class MatchedBase { TEXT, NUMBER, YES_NO, YES, DATETIME, DATE_RANGE }

/** [field]'s [MatchedType], or null where this reader does not place its type or finds no declared format. */
private fun TrackedFactBase.matchedTypeOf(field: TrackedDeclaration): MatchedType? = when (effectiveFieldType(field) ?: return null) {
    FieldType.STRING, FieldType.CUSTOM_FIELD, FieldType.ENUMERATION -> MatchedType(MatchedBase.TEXT)
    FieldType.NUMBER -> MatchedType(MatchedBase.NUMBER)
    FieldType.BOOLEAN -> MatchedType(MatchedBase.YES_NO)
    FieldType.CONFIRM -> MatchedType(MatchedBase.YES)
    FieldType.DATE_RANGE -> dateRangeFormatOf(field)?.let { MatchedType(MatchedBase.DATE_RANGE, it) }
    FieldType.DATE, FieldType.DATE_FRAGMENT, FieldType.TIME, FieldType.DATE_TIME ->
        temporalFormatOf(field)?.let { MatchedType(MatchedBase.DATETIME, it) }
    FieldType.TYPE_DEF, FieldType.UNSPECIFIED -> null
}

/**
 * The `NumberOfDifferentValues` arm, which is itself a switch on the LEADER's declared type.
 *
 * Four leaders, four outcomes, and the two this reader answers walk the rest of the list with the leader's
 * own predicate. A temporal leader hands the list to [OperationAnalysis]; a leader whose
 * effective type this reader does not resolve leaves the call unjudged rather than guessing the arm.
 *
 * **The value-validation gate runs over the WHOLE list after the kind walk**, not interleaved with it, so a
 * kind defect later than a waiving field still answers first — measured, and the reason the two walks here
 * are sequential rather than one pass.
 */
private fun TrackedFactBase.distinctDefect(fields: List<TrackedDeclaration>): FieldListDefect? {
    val leader = effectiveFieldType(fields.first()) ?: return null
    return when {
        leader in STRING_LIKE_LEADERS ->
            fields.firstOrNull { effectiveFieldType(it) in PLAINLY_NON_STRING_LIKE_TYPES }?.let {
                FieldListDefect(
                    "MVK_STRING_ENUM_AND_NON_STRING_ENUM",
                    "counts distinct values of a list led by a text, custom or enumeration field, so " +
                        "every field in it must be one of those three",
                    it,
                )
            } ?: fields.firstOrNull(::waivesValueValidation)?.let {
                FieldListDefect(
                    "MVK_INVALID_RAW_TYPE",
                    "counts distinct values, which it cannot do over a field that waives value validation",
                    it,
                )
            }
        leader == FieldType.NUMBER -> fields.firstOrNull { effectiveFieldType(it) in PLAINLY_NON_NUMBER_TYPES }
            ?.let {
                FieldListDefect(
                    "MVK_NUMBER_AND_NON_NUMBER",
                    "counts distinct values of a list led by a number, so every field in it must be one",
                    it,
                )
            }
        leader in UNCLAIMED_LEADERS -> FieldListDefect(
            "MVK_ONLY_STRING_ENUM_NUMBER_CMP_DATE_ALLOWED",
            "counts distinct values only of a text, custom, enumeration, number or date list, and the " +
                "LEADING field is what decides which",
            fields.first(),
        )
        else -> null
    }
}

private fun TrackedFactBase.finding(
    defect: FieldListDefect,
    call: ConditionCall,
    element: TrackedDeclaration,
    member: String,
): Finding = Finding(
    FindingCategory.A12_CONSTRAINT,
    FindingSeverity.ERROR,
    defect.code,
    "in `$member`: `${call.operator}` ${defect.demand}, and `${defect.field.path}` is declared " +
        "`${effectiveFieldType(defect.field)}` — drop that field from the list, or reach for an operator " +
        "whose list admits its kind",
    element.path,
    call.spanIn(member),
)
