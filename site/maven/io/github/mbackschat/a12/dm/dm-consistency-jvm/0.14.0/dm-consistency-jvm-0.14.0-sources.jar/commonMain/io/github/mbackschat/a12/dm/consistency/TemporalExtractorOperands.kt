package io.github.mbackschat.a12.dm.consistency

import io.github.mbackschat.a12.dm.consistency.syntax.OperatorId
import io.github.mbackschat.a12.dm.consistency.syntax.CONDITION_OPERATOR_IDENTITIES
import io.github.mbackschat.a12.dm.consistency.syntax.ConditionCall

/**
 * What a temporal EXTRACTOR demands of the date it reads, asked once its operand has passed the date slot.
 *
 * `CheckDatumExtractOpImpl.check` splits on the operator. The seven NUMBER extractors ask three questions in a
 * fixed order; the two that yield a date or a time ask one ([KERNEL-FINDINGS KF529],
 * `adapter.laws.CheckerTemporalExtractorAgreementTest`, mirrored by `TemporalExtractorOperandsTest`):
 *
 * | # | the question | class |
 * |---|---|---|
 * | 1 | a partially known date field: is the extracted component one its precision leaves known? | `MVK_INVALID_DATE_TYPE` |
 * | 2 | is the operand a quoted date literal? | `MVK_NO_CONST` |
 * | 3 | does the operand's format carry the extracted component? A Base Year answers it for the year | `MVK_WRONG_DATE_FORMAT_FOR_OP` |
 * | — | `DateFromDateTime`, `TimeFromDateTime`: does the format carry all six components? | `MVK_WRONG_DATE_FORMAT_FOR_OP` |
 *
 * **The partial-precision gate is not the format gate.** Every clock component is refused, and so is the
 * calendar component the precision leaves open: the day under `DAY_OPTIONAL`, the month and the day under
 * `MONTH_OPTIONAL`, everything under `YEAR_OPTIONAL`. `QuarterFromDate` extracts the month.
 *
 * **The operand is typed by [TemporalOperandReader]**, as the format A12 registers for it.
 *
 * **Silent where another family owns the answer** — a slot defect ([CheckFamily.DATE_ARGUMENT_SLOT]), a refused
 * shift or `DateTime(…)` ([CheckFamily.DATE_TIME_CONSTRUCTION_OPERANDS]), a missing Base Year, a starred operand
 * A12 refuses as a wildcard first — and on what the reader cannot type.
 */
internal fun TrackedFactBase.temporalExtractorContributions(
    element: TrackedDeclaration,
    execution: ConditionExecution? = conditionExecution(element),
): List<ConditionFinding> {
    if (execution == null) return emptyList()
    val identities = CONDITION_OPERATOR_IDENTITIES[conditionLanguage] ?: return emptyList()
    val reader = TemporalOperandReader(this, identities, execution, element)
    return callContributions(element, execution) { member, call ->
        val extractor = identities[call.operator]?.let(Extractor::of) ?: return@callContributions null
        reader.extractorDefect(extractor, call)?.findingAt(call, element, member)
    }
}

/** The nine extractors, with the component each number extractor reads — A12's `DateUtils.typeToComponent`. */
internal enum class Extractor(val id: OperatorId, val component: Component?) {
    YEAR_FROM_DATE(OperatorId.YEAR_FROM_DATE, Component.YEAR),
    QUARTER_FROM_DATE(OperatorId.QUARTER_FROM_DATE, Component.MONTH),
    MONTH_FROM_DATE(OperatorId.MONTH_FROM_DATE, Component.MONTH),
    DAY_FROM_DATE(OperatorId.DAY_FROM_DATE, Component.DAY),
    HOURS_FROM_TIME(OperatorId.HOURS_FROM_TIME, Component.HOUR),
    MINUTES_FROM_TIME(OperatorId.MINUTES_FROM_TIME, Component.MINUTE),
    SECONDS_FROM_TIME(OperatorId.SECONDS_FROM_TIME, Component.SECOND),
    DATE_FROM_DATE_TIME(OperatorId.DATE_FROM_DATE_TIME, null),
    TIME_FROM_DATE_TIME(OperatorId.TIME_FROM_DATE_TIME, null);

    companion object {
        fun of(id: OperatorId): Extractor? = entries.firstOrNull { it.id == id }
    }
}

private val CLOCK = setOf(Component.HOUR, Component.MINUTE, Component.SECOND)

/** The first gate [call] fails, in A12's own order, or null where none fails and where it may not judge. */
private fun TemporalOperandReader.extractorDefect(extractor: Extractor, call: ConditionCall): TemporalDefect? {
    val operand = call.operands.singleOrNull() ?: return null
    val from = typed(operand, call.inAFilterBody) ?: return null
    val unit = extractor.component ?: return if (from.components.containsAll(Component.entries)) null else
        TemporalDefect("MVK_WRONG_DATE_FORMAT_FOR_OP",
            "needs a stamp carrying all six date and clock components, and `${operand.text}` does not")
    if (from is ExtractedFrom.Field && from.precision != null &&
        (unit in CLOCK || unit in OPEN_UNDER_PRECISION.getValue(from.precision))) {
        return TemporalDefect("MVK_INVALID_DATE_TYPE",
            "reads `${from.path}`, declared `${from.precision}`, which leaves the component it extracts unknown")
    }
    if (from is ExtractedFrom.Literal) {
        return TemporalDefect("MVK_NO_CONST",
            "is handed the constant `${operand.text}`, whose components are already known — extract from a field")
    }
    if (unit in from.components || unit == Component.YEAR && facts.hasBaseYear) return null
    return TemporalDefect("MVK_WRONG_DATE_FORMAT_FOR_OP",
        "reads `${operand.text}`, whose format does not carry the component it extracts")
}
