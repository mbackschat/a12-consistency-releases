package io.github.mbackschat.a12.dm.consistency

import io.github.mbackschat.a12.dm.consistency.syntax.OperatorId
import io.github.mbackschat.a12.dm.consistency.syntax.SyntaxSite

import io.github.mbackschat.a12.dm.consistency.syntax.OPERATOR_SPELLINGS
import io.github.mbackschat.a12.dm.consistency.syntax.CallShape

/**
 * The places a model's declared BASE YEAR is not optional.
 *
 * Two unrelated kernel checkers ask the same one-line question of the model, and the pairing is what makes
 * this one family rather than two branches ([KERNEL-FINDINGS KF403],
 * `rulekit.validate.laws.BaseYearRequirementLawsTest`):
 *
 * | the shape | without a declared base year |
 * |---|---|
 * | the `BaseYear` constant, anywhere | `MVK_NO_BASE_YEAR` |
 * | a `Date` construction with no year parameter | `MVK_MISSING_YEAR` |
 *
 * **The constant is refused by its own checker wherever it stands**, so the carrier does not matter —
 * measured on three (a comparison, an extraction, a shift) rather than one, because "the constant is
 * refused" is a claim about the constant and a single carrier cannot be told apart from that carrier's own
 * operand gate.
 *
 * **The day and month parameters are checked BEFORE the year one**, so a year-less construction that is also
 * out of range answers with the day's class. That gate is [dateConstructionContributions]' and is read
 * through [aDateSlotAnswersFirst] rather than restated here.
 *
 * **The `Time` construction has no year to omit** and takes any prefix of its three slots, so the same
 * two-argument shape is admitted there. That row is the discriminator against the tempting reading "a short
 * construction needs a base year".
 *
 * **A declared base year does not simply relax the model.** It DISABLES the year-agreement walk of the
 * range-overlap operators ([dateRangeOperandListFindings]) while ENABLING these two shapes, so a family
 * treating it as one switch in one direction would get the other half backwards.
 *
 * **The error MESSAGE is a third place, and it is [messageBaseYearDefect]'s**, because A12 judges it only
 * beside a sound DSL member and this family's classes are DSL classes.
 *
 * **Silent on everything when the model declares a base year**, which is the whole family's precondition,
 * and on a `Date` construction this reader cannot parse into slots.
 */
internal fun TrackedFactBase.baseYearContributions(element: TrackedDeclaration): List<ConditionFinding> {
    if (hasBaseYear) return emptyList()
    val execution = conditionExecution(element) ?: return emptyList()
    val keywords = OPERATOR_SPELLINGS[conditionLanguage] ?: return emptyList()
    val baseYear = keywords[OperatorId.BASE_YEAR] ?: return emptyList()
    val construction = keywords[OperatorId.DATE] ?: return emptyList()
    return execution.recognition.sites.mapNotNull { site ->
        when (site) {
            is SyntaxSite.Completion -> {
                if (site.kind == SyntaxSite.Kind.CONSTANT) {
                    if (execution.carrier.text.substring(site.start, site.end) != baseYear) return@mapNotNull null
                    val span = execution.carrier.semanticSpan(site.start, site.end) ?: return@mapNotNull null
                    return@mapNotNull ConditionFinding(element.key, site, constantFinding(baseYear, element, span.member, span))
                }
                if (site.kind != SyntaxSite.Kind.CALL) return@mapNotNull null
                val shape = execution.callsByStart.getValue(site.start)
                if (shape.operator != construction) return@mapNotNull null
                val span = execution.carrier.semanticSpan(shape.at, shape.end) ?: return@mapNotNull null
                yearlessFinding(shape, element, span.member)?.let {
                    ConditionFinding(element.key, site, it.copy(span = span))
                }
            }
            else -> null
        }
    }
}

/**
 * The Base Year terminal in an error MESSAGE, in a model that declares no Base Year.
 *
 * **A12 answers it from a different vocabulary.** The constant written as a message parameter —
 * `${'$'}BaseYear${'$'}`, or with the signed offset it admits unbounded — draws the unprefixed `NO_BASE_YEAR`
 * rather than `MVK_NO_BASE_YEAR`, measured on both language spellings
 * (`rulekit.validate.laws.RuleMessageParameterLanguageLawsTest`). The carrier decides the class, so this and
 * [baseYearContributions] cannot share a code however alike the question is.
 *
 * **And A12 judges it only beside a sound condition or operation**, on either carrier, which report assembly
 * applies rather than this family. That includes a condition naming the constant too: its `MVK_NO_BASE_YEAR`
 * is a DSL class, so the model is reported once, on the condition
 * (`rulekit.validate.laws.MessageParameterConditionDependencyLawsTest`, [KF338]).
 */
internal fun TrackedFactBase.messageBaseYearDefect(): String? = if (hasBaseYear) null else "NO_BASE_YEAR"

/** Raised by `konstanteReferenzjahr`, whose production is the constant's one token. */
private fun constantFinding(baseYear: String, element: TrackedDeclaration, member: String, span: TextSpan) = Finding(
    FindingCategory.A12_CONSTRAINT,
    FindingSeverity.ERROR,
    "MVK_NO_BASE_YEAR",
    "in `$member`: `$baseYear` stands for the model's reference year, and this model declares none — " +
        "set `modelInfo.baseYear`, or write the year the condition means",
    element.path,
    span,
)

/**
 * The year-less construction's finding, or null where it carries its year or an earlier slot answers.
 *
 * A12 reads the year from the model only when the parameter is absent, so a construction that spells one is
 * this family's business in neither direction.
 */
private fun TrackedFactBase.yearlessFinding(
    shape: CallShape,
    element: TrackedDeclaration,
    member: String,
): Finding? {
    if (shape.operands.size != YEARLESS_ARITY || aDateSlotAnswersFirst(shape, element)) {
        return null
    }
    return Finding(
        FindingCategory.A12_CONSTRAINT,
        FindingSeverity.ERROR,
        "MVK_MISSING_YEAR",
        "in `$member`: `${shape.operator}` is built from a day and a month alone, which needs the model's " +
            "reference year to complete it, and this model declares none — set `modelInfo.baseYear`, or " +
            "give the construction its own year",
        element.path,
        shape.spanIn(member),
    )
}

/** A day and a month and nothing else: the one `Date` shape whose year A12 takes from the model. */
private const val YEARLESS_ARITY = 2
