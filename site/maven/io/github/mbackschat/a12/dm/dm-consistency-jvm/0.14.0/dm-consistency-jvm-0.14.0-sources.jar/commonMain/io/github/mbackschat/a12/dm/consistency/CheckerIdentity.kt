// GENERATED from this module's Gradle version by :consistency:generateCheckerIdentity — never hand-edited.
package io.github.mbackschat.a12.dm.consistency

/**
 * The version of THIS checker build, baked in at build time from the module's own Gradle version.
 *
 * It exists so a consumer can name the checker artifact it actually resolved instead of a constant of its
 * own. `dmtool model check --engine=portable` publishes it as the portable engine's version, which is what
 * makes that receipt a statement about the resolved artifact rather than about dmtool's expectations.
 */
public const val CHECKER_VERSION: String = "0.14.0"
