package io.github.mbackschat.a12.dm.consistency

/**
 * A family of required checks, named so a report can say which ones actually ran.
 *
 * The enum is the coverage denominator's live half. Its other half — the pinned profile's full list of
 * required families — does not exist yet, which is exactly why every report currently carries a gap saying
 * so: "the reference check completed" must never read as "the analysis completed".
 *
 * **Adding a constant here touches seven places, and `docs/TESTING-SPEC.md` enumerates them** — the wiring
 * fixture's triggering declaration and evidence row, the corrective projection, that corrective's
 * reachability row, the builder-divergence disposition, and a new laws class's two registrations. Every one
 * is a guard that fires only AFTER the family is green, so reading the list first turns four failing lanes
 * into one pass; it has cost that four twice (2026-09-14, 2026-09-15).
 */
enum class CheckFamily {
    /** A rule's error target and a computation's computed field resolve to a declared element. */
    DECLARED_REFERENCES,

    /** Every entity named in a rule's condition or a computation's operations resolves. */
    CONDITION_REFERENCES,

    /**
     * A rule's and a computation's own declaration slots — the reserved name prefix and the error messages —
     * and the `header.locales` set those messages answer to, which decides what A12 collects from them.
     */
    DECLARATION_SLOTS,

    /**
     * A12's unprefixed error-text class for a declaration leaving a declared locale with no text or an empty
     * one ([KF346]), beside either message class. Its own constant rather than part of [DECLARATION_SLOTS]
     * because A12's error-text checker draws it, and that checker judges a message only beside a sound
     * condition or operation, while the prefixed slot classes it rides with are judged regardless — measured
     * on both carriers, preconditions included ([KF338]).
     */
    ERROR_TEXT_PRESENCE,

    /**
     * A computation's `computationAlternatives` — that it carries work at all, and that each of several
     * alternatives carries its own precondition.
     */
    COMPUTATION_ALTERNATIVES,

    /** A rule's `errorCondition` and `errorEntityRelPath` are present and carry text. */
    RULE_CONDITION_AND_TARGET,

    /** No group holds two children of the same name, whatever kinds they are. */
    ELEMENT_NAME_UNIQUENESS,

    /** A group's `indexFieldName` and `sortFields[].name` each name one of its own fields. */
    GROUP_ORDERING_REFERENCES,

    /**
     * …and the field each of them names is one A12 will accept as an ordering key — never a string declared
     * `noValueValidation`. Its own constant because resolving and being usable are different claims, and a
     * report that merged them would let a resolution fix read as a type approval.
     */
    GROUP_ORDERING_FIELD_TYPE,

    /**
     * …and that the group declaring sort entries REPEATS at all. Its own constant because it is a claim
     * about the carrier rather than about any entry, so a report merging it would let a group that cannot
     * be sorted read as a group whose sort fields are wrong.
     */
    GROUP_ORDERING_CARRIER,

    /**
     * A group's `repeatability` against A12's cap on it, which differs between a root and a nested group.
     * Its own constant because it is a claim about the declaration's SIZE rather than about any reference,
     * and it is the only family that reads the member for its value rather than for repeatability.
     */
    GROUP_REPETITION_COUNT,

    /**
     * A computation's `roundingMode` and each alternative's `toleranceRangeOp` — that both spell a value
     * A12 knows, and that the pair they form is one A12 permits.
     */
    COMPUTATION_ROUNDING,

    /**
     * A computation's `errorCodesToSuppress` — that it renders into a pragma A12's parser can read, and that
     * the one code it may carry is the one A12 lets a computation suppress.
     */
    SUPPRESSED_WARNINGS,

    /**
     * A `variantFilter` — that A12 can bind it, on every carrier that declares one, and WHICH declarations
     * it takes out of A12's check, which is a rules-and-computations question because on a field the same
     * spelling deletes the field instead. The family is unusual in that its main output is a coverage gap
     * rather than a finding, because A12 accepts the models that second half concerns.
     */
    VARIANT_FILTER,

    /**
     * A rule's `guiPatterns` and `variantErrorMessages` — that A12's reader can BIND them, and nothing else.
     * A12 checks neither member's CONTENT, so an undocumented `guiPatterns` key and a variant name no filter
     * mentions are both admitted; the family exists because the shapes their readers refuse make the whole
     * model unloadable, and a clean report for one of those would be read as a verdict.
     */
    RULE_PRESENTATION_MEMBERS,

    /**
     * That every member A12 binds to TEXT actually holds text — one law across all three carriers that own
     * such a member. A container there refuses A12's reader outright, so the model never loads; a non-text
     * scalar is coerced and is not this family's business, nor is a blank or absent member, which the
     * families owning those members already judge.
     */
    STRING_SLOT_BINDING,

    /**
     * That every field HAS a `fieldType`, that it names a type A12 declares, and that it carries the body
     * that type reads and constructs from — the discriminated union, never its contents. Two tiers ride one
     * constant because they are one member's law: a shape A12's reader refuses never loads, while a missing
     * member or an empty body loads and then fails as A12 builds. The message says which.
     */
    FIELD_TYPE_BINDING,

    /**
     * That a date field's declared CONFIG agrees with its declared FORMAT — the pre-1900 check needs a
     * year-bearing format and a partial `datePrecision` needs a complete pure date. Both are A12's own
     * consistency codes rather than reader refusals, and both are asked only over the format vocabulary A12
     * is measured to admit: an unrecognised format leaves this family silent, since the admitted set is a
     * probe's result and not a closed one.
     */
    TEMPORAL_CONFIG,

    /**
     * That a declared GROUP or FIELD name is one A12's own alphabet takes. Two laws rather than one: a group
     * refuses a leading underscore a field admits and admits a German umlaut a field refuses, so each
     * carrier is asked its own question. The shared path predicate also gates field-message reach.
     * The group's codeless 60-character limit is left to A12.
     */
    ELEMENT_NAME_ALPHABET,

    /**
     * A FIELD name whose last dotted segment is `.value`, which A12's field-name gate reserves. Its own
     * constant because it is a reserved WORD and not an alphabet, and because it is reported BESIDE
     * [ELEMENT_NAME_ALPHABET]'s dot class rather than instead of it — A12 states both, this one first.
     */
    FIELD_NAME_RESERVED_SEGMENT,

    /**
     * That an Enumeration's categories pair with its values. The pairing is POSITIONAL, so the law is equal
     * cardinality rather than set membership, and A12 names each unpaired element separately — a value with
     * no token and a token with no value are different codes, and both are reported once per distinct element.
     */
    ENUM_CATEGORY_ALIGNMENT,

    /**
     * That every declared ENUM VALUE is spelled in the characters `content.modelConfig.supportedCharacters`
     * admits. The restriction is a runtime constraint A12 bakes into generated code, and `checkConsistency`
     * re-runs the generator — so it is an authoring gate too. Enum values are the only declared strings it
     * judges, measured against a name, a message, a category token and a string field's hint list that are
     * all admitted — the last of those reads as in scope from A12's source and is dead on `30.8.1`.
     */
    ENUM_VALUE_CHARACTERS,

    /**
     * The four characters A12 refuses in an enumeration's declared TEXTS — a tab, a pipe, and the two line
     * breaks — whichever of its three carriers holds them. Separate from [ENUM_VALUE_CHARACTERS] because that
     * family judges a value against the MODEL's own restriction while this law is A12's and is asked of every
     * model, and because the carrier picks the class here where there only one class exists. The line-break
     * half is refused a gate earlier and CODELESS, so the family owns a code for it rather than citing one
     * A12 does not use there.
     */
    ENUM_TEXT_FORBIDDEN_CHARACTERS,

    /**
     * That no text A12 validates as part of the model carries a character outside the Basic Multilingual
     * Plane. A12 reads the model as a document of its own metamodel and refuses such a character in it with
     * a finding carrying no class, so the family owns a code for it. Its carriers are measured one by one,
     * and the labels of the model, a group and a field are not among them.
     */
    MODEL_TEXT_REPERTOIRE,

    /**
     * The VALUES inside a string type's hint list, against that type's own length bounds and each other.
     * Separate from [STRING_TYPE_PARAMETERS], which judges the parameters against one another and answers
     * whether the list may be there at all — A12 reports the list-level refusal and these value laws
     * together, so merging them would let one read as pre-empting the other.
     */
    HINT_LIST_VALUES,

    /**
     * `ValueNotConsistent`'s subject must be an enumeration with a TABLE reference, which no stored model
     * declares. Its own constant rather than a row of an operand-kind family because the law is not about
     * the subject's kind at all: every kind fails it alike, the demand being for a backing A12's own reader
     * refuses, so a report merging it would read as "wrong field type" where the answer is "no admissible
     * subject exists".
     */
    TABLE_ENUM_OPERAND,

    /**
     * The seven legacy FORM constructs, which A12 refuses by name in an A12 model. Its own constant because
     * it is the only family keyed on the model's condition LANGUAGE rather than on a declaration's shape:
     * the spellings exist in no English bundle, so an English model's identical text is a parser refusal
     * under a different class, and a family merging the two would name this one on that.
     */
    H_MODEL_FORM_CONSTRUCT,

    /**
     * An enumeration's `sValue` names one of the values it declares. Its own constant because it is a claim
     * about a single distinguished member rather than about the value list, and a report merging it would
     * let a special value pointing nowhere read as a defect in the values themselves.
     */
    ENUM_S_VALUE_DOMAIN,

    /**
     * That a declared string `pattern` passes A12's admission gate — its TEXTUAL half. The gate blacklists
     * source-character adjacencies rather than the expression they spell, so an escaped metacharacter
     * before a quantifier is refused like an unescaped one. Its other half, Java regex compilability,
     * belongs to one engine and is left to A12 with a gap saying so.
     */
    STRING_PATTERN_ADMISSION,

    /**
     * That a declared string type's `pattern` and its own `errorMessage` answer for each other — A12 refuses
     * either alone. A message counts only where it gives A12 a non-blank text for a DECLARED locale, so an
     * empty list, a blank text and a text for an undeclared locale are all no message at all; once some
     * declared locale is answered and another is not, the untranslated half is reported separately and
     * independently of the pattern.
     */
    STRING_PATTERN_MESSAGE,

    /**
     * That a field type's OWN error message — a String type's pattern message, an Enumeration's invalid-value
     * message — is text A12's field-message check admits. The check is not the rule message's: it asks UTF-16
     * encodability first, then the same two character gates, then an even `$` count, and admits only
     * `field` and `field.value` between two `$`, spelled in the CONDITION language. One finding per field, from
     * the first declared locale that fails, and none for a field whose path A12's element walk never reaches.
     */
    FIELD_TYPE_MESSAGE_TEXT,

    /**
     * That a declared string type's own parameters agree with each other — what `noValueValidation`
     * excludes, the hint list it forbids, the line-break flag it requires, and the two length laws beside
     * them. The members are read the way A12 encodes them, so the sentinel `-1` is NO bound rather than a
     * negative one, and the laws are reported independently because A12 reports them so.
     */
    STRING_TYPE_PARAMETERS,

    /**
     * That a declared number type's fractional-digit pair and its value range are ones A12 accepts. The
     * digit law is not a plain comparison of the declared members: an absent one reads as 0 and a negative
     * maximum takes the pair out of the check. The declared SCALE rides here too, as the build-tier verdict
     * A12 has no code for.
     */
    NUMBER_TYPE_DIGITS,

    /**
     * That an enumeration's VALUE tokens are distinct and that its per-locale labels are finished. Almost
     * nothing about a token's spelling is A12's business here — an empty one, a spaced one and a very long
     * one are all admitted — and the label law is that once ANY value carries an entry for a DECLARED
     * locale, every value owes a non-blank text for every declared locale.
     */
    ENUM_VALUE_LABELS,

    /**
     * That no condition NAMES a group carrying no field anywhere beneath it. Declaring one is legal, so this
     * judges the reference and not the declaration, and emptiness is over the subtree — a group whose only
     * content is a populated subgroup is admitted wherever an empty one is refused.
     */
    EMPTY_GROUP_OPERAND,

    /**
     * That a rule's condition NAMES the field its error is attached to. A resolvable target is necessary and
     * not sufficient; naming a group the target sits in counts, and naming a field inside a target group
     * does not.
     */
    ERROR_FIELD_REFERENCE,

    /**
     * That no group-list quantifier names one group twice, or names a group and something beneath it. The
     * gate is per CALL rather than per condition, so the family reads the parsed argument list; a starred
     * operand is outside it, and an operand that does not resolve pre-empts it.
     */
    GROUP_LIST_OPERANDS,

    /**
     * …and that no group-list quantifier names a ROOT group its carrier does not admit. Its own constant
     * because repeating an operand and naming a root are different claims about one list: three carriers
     * refuse a root outright and three admit it as the sole operand, and a starred root — exempt from the
     * duplicate comparison — is fully inside this one.
     */
    GROUP_LIST_ROOT_OPERAND,

    /**
     * …and that no group predicate that refuses a FIELD is handed one. Its own constant because its carrier
     * set is neither of the others': the five group-list quantifiers ADMIT a field operand, and only the
     * count and the two scalar presence predicates refuse one.
     */
    GROUP_LIST_OPERAND_KIND,

    /**
     * That no reference puts a repetition wildcard on something with no repetitions. A reference-level law
     * rather than an operand-level one, because A12 answers it ahead of both the slot's own wildcard gate and
     * the entity gate, and with a class fixed by WHAT the star lands on rather than by where it stands: a
     * name that names no repetition, the rule's own group, or a relative up-step.
     */
    REPETITION_WILDCARD_TARGET,

    /**
     * That a computation computes into a FIELD. A rule's error target resolves the same way and ADMITS a
     * group, so the two slots are measured apart rather than sharing a rule; the Kernel refuses a
     * group-valued computed field at the BUILD tier, so the report says the model is not buildable rather
     * than naming A12's key for it.
     */
    COMPUTED_TARGET_KIND,

    /**
     * What `Length` over a RAW-TYPE field may look like. A STRING declaring `noValueValidation` admits its
     * length only as the whole rule condition `Length(f) > c` or the mirror — the max-length declaration A12
     * lifts out of the generated validation — and a computation may not take it in any member. The other
     * value windows A12 closes on such a field are NOT reported: deciding them needs per-operator value
     * positions, which this checker does not reproduce.
     */
    RAW_TYPE_LENGTH,

    /**
     * That a computation does not compute into the field a repeatable group is INDEXED by. A12 answers with
     * a key of its own rather than refusing to build, and the law follows the resolved TARGET rather than
     * the computation's own group. A `sortFields` entry is named by the same kind of member and carries no
     * such restriction, which is the control that keeps the two apart. A12's next gate on the same target,
     * which this family also answers, refuses a computed field whose path carries a dot or a colon.
     */
    COMPUTED_TARGET_INDEX_FIELD,

    /**
     * The predicates a COMPUTATION's precondition may not use. A12 normalizes a calculation rule's condition
     * and refuses an application condition or `RepetitionNotUnique` there, while a RULE condition uses both
     * freely. Its third prohibited feature has no English spelling, so this family does not report it.
     */
    COMPUTATION_PRECONDITION_FEATURES,

    /**
     * What each `RepetitionNotUnique` key has to be before either branch runs: one field, unstarred, unkeyed,
     * validated. Its own constant rather than part of [REPETITION_KEY_PLACEMENT] because A12 asks these four
     * gates over the whole list ahead of the scope and the placement alike, and each of the three branch
     * families stays silent until they pass.
     */
    REPETITION_KEY_LIST,

    /**
     * That a `RepetitionNotUnique` key has a repetition to be asked about — a repeatable group strictly
     * between the rule's own group and the key. Its own constant rather than part of the wildcard family
     * because the demand is on the KEY's placement rather than on a spelling: the class collapses three
     * shapes that read as different defects, and a key outside the rule group hands the verdict to a
     * different class entirely, where this family stays silent.
     */
    REPETITION_KEY_PLACEMENT,

    /**
     * That a `RepetitionNotUnique` `@From` scope names a REPEATABLE group. Its own constant rather than part
     * of [REPETITION_KEY_PLACEMENT] because the demand is on the SCOPE rather than on where the keys sit,
     * and the two are independent: a legal scope admits an illegal key placement and the reverse.
     */
    REPETITION_SCOPE_GROUP,

    /**
     * Where a `RepetitionNotUnique` key has to sit relative to its `@From` scope or to the rule's own group.
     * Its own constant rather than part of [REPETITION_KEY_PLACEMENT] because A12 gates containment BEFORE
     * the repetition demand that family reports, and the two answer on disjoint shapes: a key inside the
     * rule group with no repetition between, against a key outside the bound entirely.
     */
    REPETITION_KEY_CONTAINMENT,

    /**
     * That the temporal operands of an entity-list aggregate declare the same date COMPONENTS. Its own
     * constant rather than part of [FIELD_OPERAND_KIND] because the demand is not on any operand's kind: the
     * list is typed from its leader and every later operand is then judged on what its FORMAT spells, so two
     * fields of one kind can disagree and two of different kinds can agree.
     */
    TEMPORAL_AGGREGATE_OPERANDS,

    /**
     * Which repeatable levels a `Having` filter's BODY may name, and the one it must. Its own constant
     * rather than part of [FIELD_VALUE_READ_OPERAND] because that family judges a STAR in the body while this one
     * judges the levels the body's unmarked references ride — distinct check actions, with the star
     * refused before either is asked.
     */
    FILTER_BODY_GATES,

    /**
     * That the `$` outer marker stands only inside a `Having` filter. Its own constant rather than part of
     * [FILTER_BODY_GATES] because the law is POSITIONAL and names no carrier: A12 refuses the marker from
     * one locus reached by every entity spec, so the family reads whole conditions where that one reads a
     * filter's operand.
     */
    OUTER_MARKER_POSITION,

    /**
     * That no GROUP-CONDITION operand carries a repetition wildcard where its operator bars one. Its own
     * constant rather than part of [REPETITION_WILDCARD_TARGET] or [FIELD_VALUE_READ_OPERAND] because here the star
     * lands on a group that legitimately repeats and the OPERATOR alone picks the class: A12 splits the seven
     * group conditions three ways, and two of them admit the very star the other five refuse.
     */
    GROUP_CONDITION_WILDCARD,

    /**
     * That `SumOfProducts`' two operands are PARALLEL: one owning group, and each starring exactly the
     * lowest repeatable level between the rule's own group and its field. One constant for four codes
     * because A12 decides them in one operator's gate chain and their ORDER is what a reproduction has to
     * get right — three of the cells that break two of the laws at once are answered by the earlier gate.
     */
    SUM_OF_PRODUCTS_OPERANDS,

    /**
     * That one numeric operand-list `Min`/`Max` call lists at most one literal. Per CALL and never
     * flattened: a literal inside a nested call or inside arithmetic belongs to that operand and not to the
     * outer budget, so a family counting literals over the text would refuse two shapes A12 admits.
     */
    OPERAND_LIST_CONSTANT_BUDGET,

    /**
     * What a semantic index may CARRY and where the group it indexes has to be — six classes of one chain,
     * ordered as A12 decides them. Its own constant rather than part of [SEMANTIC_INDEX_KEY] because that
     * family owns the chain's FIRST gate and reports it wherever the key is a group, while these six are
     * reached only once the key is a legal field.
     */
    SEMANTIC_INDEX_STRUCTURE,

    /**
     * That a semantic index's KEY names a field rather than a group. Its own constant rather than part of
     * [REPETITION_KEY_PLACEMENT] because the key of an index selects one repetition by VALUE, where a
     * repetition-uniqueness key declares what makes rows distinct — different laws over the same word.
     */
    SEMANTIC_INDEX_KEY,

    /**
     * That a condition calls `RepetitionNotUnique` at most once. Its own constant rather than part of
     * [REPETITION_SCOPE_GROUP] because it is a whole-RULE gate counting calls, where every other family here
     * judges one construct's own operands — and A12 runs it after the construct gates have had their say.
     */
    REPETITION_NOT_UNIQUE_COMBINATION,

    /**
     * That `RepetitionNotUnique` does not sit in a condition that PARALLEL-iterates. Its own constant rather
     * than part of [REPETITION_NOT_UNIQUE_COMBINATION] because the demand is on the condition's ITERATION
     * shape rather than on how many calls it carries, and the two gates are independent.
     */
    PARALLEL_ITERATION_UNIQUENESS,

    /**
     * That no `Having` filter hangs off an operand A12 marked as parallel-iterated. Its own constant rather
     * than part of [PARALLEL_ITERATION_UNIQUENESS] because the two are separate gates of the same method
     * with separate preconditions — one needs a uniqueness call, this one a filter — and A12 runs the
     * uniqueness gate first, which is what makes the boundary between them observable. It also asks the
     * method's third gate, a filter BODY that parallel-iterates, which reads the same two marking passes.
     */
    FILTERED_ENTITY_ITERATION,

    /**
     * What an arithmetic expression's operands may BE, how many divisions and powers it may carry, and what
     * an exponent has to be. One constant for the five classes because `CheckOperationImpl.check` asks them
     * of one construct — an operation context — and the type walk PRE-EMPTS both arity gates inside it, so
     * splitting them would let a checker name a second class on a model A12 answers once.
     */
    ARITHMETIC_OPERATION_GATES,

    /**
     * Which field declarations each constant KIND of `NumberOfValueInFields` admits in its list. One
     * constant for the four classes because `CheckAnzahlWertOpImpl.check` is one switch on the constant, so
     * which of them answers is decided by what stands to the left of the `In` rather than by a property a
     * family could split by.
     */
    VALUE_IN_FIELDS_CONSTANT_KIND,

    /**
     * What a value-list quantifier's field list may carry, and what may stand opposite it. One constant for
     * every class it names because `CheckFeldListeUndWerteListenBedingungImpl.check` asks them in a fixed
     * order over the same two lists, value validation and each list's repeat included, so which answers
     * depends on where the walk stops rather than on a property a family could split by.
     */
    VALUE_LIST_CONDITION_GATES,

    /**
     * How many entities each entity-list operator's argument list needs. One constant for the six classes
     * because they are six calls to the same handful of gates in `CheckEntityListenUtils`, differing only
     * in which operator's switch reaches them — the operator decides the class, so nothing else could.
     */
    ENTITY_LIST_ARITY,

    /**
     * The duplicate and root-group gates an entity list meets before its operator asks anything of its own.
     * One constant for the four classes because they are the same two shared utilities in every caller —
     * what varies is only WHICH caller asks the root-group one, which is a property of the table rather
     * than of a family a reader could split by.
     */
    ENTITY_LIST_PRE_GATES,

    /**
     * What KIND of field `FieldValuesNotUnique` admits, and how the temporal ones must be spelled. One
     * constant because both questions are one gate in A12 under one class — the kind arm and the spelling
     * arm are the same `checkOnlyStringEnumNumberOrDateWithSameFormat` walk.
     */
    FIELD_VALUES_NOT_UNIQUE_OPERAND_KIND,

    /**
     * What KIND of declaration each field-LIST operation admits in its entity list. One constant for the
     * three classes because `CheckFeldListenOpImpl.check` is one switch on the operator over one list — the
     * arms differ in what they demand, never in where or when they are asked.
     */
    FIELD_LIST_OPERATION_OPERANDS,

    /**
     * What a date-arithmetic operator demands of the date it shifts and of the amount it shifts by. One
     * constant for the four classes because `CheckDatumAddOpImpl.check` asks them in a fixed order over one
     * operand, so which answers is a property of that order rather than of a family a reader could split.
     */
    DATE_ARITHMETIC_OPERANDS,

    /**
     * Rounding's entity/operation operand gates and digit count, plus Abs's shared immediate-operation gates
     * (KF167). The historical identity stays stable; only rounding asks the digit-count question.
     */
    ROUNDING_OPERANDS,

    /**
     * Single-entity value operators' kind, star and type gates after their operand read. The four field
     * operators require a field; CurrentRepetition requires a group (KF122). The historical family name
     * remains stable while the shared local-gate implementation covers both required kinds.
     */
    FIELD_VALUE_OPERATOR_OPERANDS,

    /**
     * What the field-value read `[ … ]` demands of the one entity it names. One constant for the four classes
     * because `CheckFeldWertOpImpl.check` asks them in a fixed order on one spec, so the first that fails is
     * the one A12 names.
     */
    FIELD_VALUE_READ_OPERAND,

    /**
     * What each comparison OPERATOR demands of the two sides it joins. One constant for the three classes
     * because `CheckVergleichsBedingungImpl.check` asks them in a fixed order ahead of every agreement
     * gate, so which answers depends on where that walk stops.
     */
    COMPARISON_OPERATOR_OPERANDS,

    /**
     * What a confirm or boolean declaration may be compared to, and with which equality operator. One
     * constant for the two classes because `CheckVergleichsBedingungImpl.checkYesAndYesNoOperations` is one
     * method whose arms are the two kinds themselves, so the declaration decides the class and nothing else
     * could.
     */
    BOOLEAN_COMPARISON_AGREEMENT,

    /**
     * What a text or enumeration side of a comparison needs of its partner, and which written-out values an
     * enumeration admits. One constant for the two classes because `CheckVergleichsBedingungImpl.checkStringOrEnumType`
     * asks them in one walk per side, the domain question only where the partner is written out — so which
     * answers depends on where that walk stops.
     */
    STRING_ENUM_COMPARISON_AGREEMENT,

    /**
     * What equality demands of two numbers' declared scales, and what a number may stand against at all. One
     * constant for the two classes because `CheckVergleichsBedingungImpl.checkNumberComparison` asks them in
     * one method, the scale question only once the kind question has passed — so which answers depends on
     * where that walk stops.
     */
    NUMBER_COMPARISON_SCALE,

    /**
     * What a date or date-range side of a comparison demands of its partner. One constant for the two
     * classes because `CheckVergleichsBedingungImpl` asks them in two adjacent methods with one shared
     * precedence — the date arm claims every partner of another kind, so which answers depends on where
     * that pair of walks stops.
     */
    TEMPORAL_COMPARISON_AGREEMENT,

    /**
     * What a pattern comparison demands of its two sides. One constant for the four classes because
     * `CheckVergleichsBedingungImpl.checkPatternOp` asks them in a fixed order inside one method, so which
     * answers depends on where that walk stops rather than on anything a family could split by.
     */
    PATTERN_COMPARISON_OPERANDS,

    /**
     * That every repetition an operand crosses unstarred is one the target's own coordinates address — or,
     * where it is not, that the two branches iterate JOINTLY on a shared index field. One constant for the
     * five classes of that walk because A12 asks them as one gate chain per level, and because which class
     * answers depends on the level reached rather than on anything a family could split by.
     */
    OPERAND_REPETITION_SCOPE,

    /**
     * What each SLOT of a `Date` or `Time` construction admits, on all three of its arms — a quoted
     * constant's range and width, which extract operator belongs in which slot, and what a field component
     * has to declare to stand in one. Its own constant because A12 walks the construction's slots left to
     * right, so the answering slot rather than any gate picks both the class and the component a report has
     * to name.
     */
    DATE_CONSTRUCTION_SLOT,

    /**
     * That no path segment carries the H-model `.*` repetition suffix. Its own constant rather than part of
     * [REPETITION_WILDCARD_TARGET] because the demand is on the SPELLING rather than on where a star lands,
     * and A12 gates it between resolution and the landing site rather than alongside it.
     */
    H_MODEL_PATH_SUFFIX,

    /**
     * That the two SCALAR field predicates are not handed a group. Its own constant rather than part of
     * [GROUP_LIST_OPERANDS] because the carrier set is the mirror one and measured separately — the eight
     * field-LIST carriers expand a group operand instead of refusing it.
     */
    FIELD_OPERAND_KIND,

    /**
     * What a `Having` filter's own operand may be. Its own constant rather than part of [FIELD_VALUE_READ_OPERAND]
     * because that family judges reads in the filter BODY, with the operand's
     * chain running first.
     */
    FILTERED_OPERAND_KIND,

    /**
     * That a `->` category access names a category its Enumeration declares. Its own constant rather than
     * part of [ENUM_CATEGORY_ALIGNMENT] because that family judges a DECLARATION and this judges a
     * REFERENCE to one — a model can be defective in either without the other.
     */
    CATEGORY_REFERENCE,

    /**
     * That an entity list whose carrier calls `checkNoCategories` projects no category. Its own constant
     * rather than part of [CATEGORY_REFERENCE] because that family judges the spec as it is read and this
     * judges the LIST once its carrier asks, which is behind or ahead of the duplicate gates by carrier.
     */
    ENTITY_LIST_CATEGORY_GATE,

    /**
     * Everything the two SCALAR value-list predicates demand of their subject field and of the list it is
     * compared against — `CheckFeldUndWerteListenBedingungImpl.check`, whose gates run in one order. Its own
     * constant rather than part of [ENUM_VALUE_CHARACTERS] because that family judges a declared value's
     * spelling and this judges a condition's REFERENCE to one, among the other demands of the same method.
     */
    SCALAR_VALUE_LIST_GATES,

    /**
     * That every date operator's DATE-ARGUMENT slot holds something the slot takes — a date-kind field
     * without a star, one of the four date-constant shapes, or a date-valued extraction. Its own constant
     * because `CheckDatumAngabeImpl` is a SHARED checker: the gates belong to the slot rather than to any
     * operator, so folding them into a carrier's family would need one copy per carrier.
     */
    DATE_ARGUMENT_SLOT,

    /**
     * That the ranges a range-overlap operator compares are date ranges, interpret their year the standard
     * way, and agree about carrying one. Its own constant because the two walks live in
     * `CheckEntityListenUtils` and are called by two different constructs, so the law belongs to the RANGE
     * LIST rather than to either carrier's method.
     */
    DATE_RANGE_OPERAND_LIST,

    /**
     * That each of the two validity conditions holds what it takes — a text or enumeration field with a
     * non-empty predefined-type name, or a date construction naming at least one entity. Its own constant
     * because one keyword spells two grammar rules with two checker classes, and the operand shape rather
     * than the operator is what decides which law applies.
     */
    VALIDITY_CONDITION_OPERANDS,

    /**
     * That a condition asking the model for its reference year is written in a model that declares one —
     * the `BaseYear` constant and the year-less `Date` construction. Its own constant because the two
     * shapes are checked by unrelated kernel classes and share only the model-level declaration, which is
     * what makes the law a property of the MODEL rather than of either construct.
     */
    BASE_YEAR_REQUIREMENT,

    /**
     * That the two SUBSTRING operators cut a field they can cut, over an interval that exists. Its own
     * constant because one kernel method checks both operators and chains six classes over the operand and
     * the interval together, so the law belongs to the CUT rather than to either operator.
     */
    RANGE_OPERAND_GATES,

    /**
     * That two declarations a comparison equates agree about LABELLING their values, and label the values
     * they share the same way. Its own constant because the question is about a PAIR rather than about
     * either side — the same enumeration is fine opposite one partner and refused opposite another — which
     * is the one shape `STRING_ENUM_COMPARISON_AGREEMENT`'s per-side walk cannot carry.
     */
    ENUM_DISPLAY_COMPARABILITY,

    /**
     * That `ValueAsDate` resolves a field A12 can resolve — one operand, four gates, one chain. Its own
     * constant because the operator's whole law is about the OPERAND's declaration, and the class it draws
     * is the same for every declaration it refuses, so a report merging it into a kind family would lose
     * which of the four gates answered.
     */
    VALUE_AS_DATE_OPERAND,

    /**
     * That a computation writing into an ENUMERATION reads a source the target can show. Its own constant
     * because the law is about the TARGET's declared kind rather than about any operand — the identical
     * operation is admitted into a text field — and because it is the only family reproducing a gate from
     * A12's CALCULATION module rather than its parser.
     */
    ENUM_COMPUTATION_SOURCE,

    /**
     * That a rule reading a repetition does not name its error field only through a ROOT group — A12 cannot
     * then say which repetition the error attaches to. Its own constant because the demand is on the
     * CONDITION's reach rather than on the target's existence, which `ERROR_FIELD_REFERENCE` already owns,
     * and because the carrier of the offending read picks between two classes.
     */
    ERROR_TARGET_ITERATION,

    /**
     * That every repetition a rule's condition iterates is also iterated by a reference naming its error
     * field. Its own constant because the demand is on the error field's references BINDING the iteration —
     * a starred reference names the field without binding it — where `ERROR_TARGET_ITERATION` owns a target
     * reached only from above the rule's group, and the two arms of A12's check are mutually exclusive.
     */
    ERROR_FIELD_ITERATION_BINDING,

    /**
     * That an iterating rule's condition cannot be true for a repetition nobody filled. Its own constant because
     * it is the last whole-rule check A12 runs and judges the condition's connective structure, which no other
     * family reads, on the rule's own iteration and across parallel groups alike.
     */
    ITERATION_GUARD,

    /**
     * That a rule or computation which ITERATES writes into a field at or below its own declaring group.
     * Its own constant because A12 answers it during the PARSE, ahead of every class `ERROR_TARGET_ITERATION`
     * and the operand families draw on the same reads — and because the two constructs differ in what
     * derives their iteration, which no family keyed on the written field alone could express.
     */
    ERROR_TARGET_CONTAINMENT,

    /**
     * That the model's computations do not depend on each other in a CIRCLE. A12 sorts the calculated fields
     * topologically and refuses a graph it cannot order. A read in a PRECONDITION builds an edge just as an
     * operation read does, and the two ends may sit in different groups. A one-node circle — a computation
     * reading its own target — is A12's other law and is deliberately not reported here.
     */
    COMPUTATION_CYCLE,

    /**
     * That a computation does not read the field it writes. The predicate is CONTAINMENT rather than
     * equality, so the computed field's own group and every group above it are reads of it; `GroupFilled`
     * over a single entity and a `CurrentRepetition` operand are A12's two carved exemptions. A PROJECTED
     * self-read — through an enum category or a semantic index — is A12's other class and is reported as
     * that one, pre-empting the plain one across the whole computation. Silent on a NUMBER target unless the
     * model suppresses the scale gate that answers ahead of both.
     */
    COMPUTATION_SELF_READ,

    /**
     * That an error message only names entities its own declaration already reads. The membership set is the
     * carrier's — a rule's condition references, a computation's target plus what its own members read — and
     * only the PLAIN `$Name$` and `$Name.value$` forms are read, because every other parameter form has a
     * gate and a class of its own.
     */
    MESSAGE_PARAMETER_REFERENCE,

    /**
     * That an error message parameter's SEMANTIC INDEX repeats a pairing its own condition wrote. Its own
     * constant rather than part of `MESSAGE_PARAMETER_REFERENCE` because the question is about the KEY and
     * not about membership: the two forms draw different classes on the same unresolvable parameter, and one
     * field — the indexed group's index field — is admitted here that the membership rule would refuse.
     */
    ERROR_TEXT_SEMANTIC_INDEX,

    /**
     * That an error message parameter's CATEGORY suffix names a category the field's own enumeration
     * declares. Its own constant because the three classes are the message grammar's, not the condition's:
     * the same projection inside a condition draws `MVK_CATEGORY_NOT_ALLOWED` and its siblings, and this
     * surface answers with A12's unprefixed error-text vocabulary instead.
     */
    ERROR_TEXT_CATEGORY_SUFFIX,

    /**
     * That the `$index(…)$` message terminal names an index field on the ERROR ENTITY's own path. Its own
     * constant because the terminal is a third parameter form with five gates of its own, and only the first
     * — the argument — is reproduced: the four after it are computed from the condition's references to the
     * same index field, and the measured ordering shows the last one never runs when the first fails.
     */
    ERROR_TEXT_INDEX_TERMINAL,

    /**
     * That an error message's TEXT carries no control character. A12 splits the law in two — a line break
     * has its own class — and runs them in ORDER, so a text carrying both draws only the line-break one.
     * A repertoire restriction is a different law and is not this family's.
     */
    MESSAGE_TEXT_CHARACTERS,

    /**
     * That an error message closes every parameter it opens. Its own constant rather than part of
     * [MESSAGE_TEXT_CHARACTERS] because the character gate PRE-EMPTS this one, so the two are ordered rather
     * than alternatives — and the gate is already exposed for exactly this kind of consumer.
     */
    MESSAGE_PARAMETER_SYNTAX,

    /**
     * What an error message's `$#…$` GROUP position may name. Its own constant rather than part of
     * [MESSAGE_PARAMETER_REFERENCE] because the two positions resolve the SAME WORDS differently — the
     * shorthands admitted here are refused there — so one reader would have to branch on position anyway.
     */
    MESSAGE_GROUP_PARAMETER,

    /**
     * The two further gates an error message's `.value` SUFFIX passes that its plain form does not — the
     * condition must read the field through something other than a star alone, and the field must declare a
     * validated value. Separate from [MESSAGE_PARAMETER_REFERENCE] because membership is what that family
     * answers and both of these sit BEHIND it, on the one form that carries them.
     */
    MESSAGE_VALUE_SUFFIX,

    /**
     * That an error message names the Base Year terminal only in a model that declares a Base Year. Its own
     * constant rather than part of [BASE_YEAR_REQUIREMENT] because the two sit in different members: the
     * condition's class is a DSL class, and A12 judges this one only beside a sound DSL member ([KF338]).
     */
    MESSAGE_BASE_YEAR,

    /**
     * That every DSL-bearing member can be TOKENIZED — the syntax layer's first phase, and the only one
     * decidable without a grammar. Whether the tokens then form a condition A12's parser accepts is a
     * separate question this family does not answer.
     */
    CONDITION_LEXICALITY,

    /**
     * Recognition failures at EOF classified as incomplete input by the shared syntax verdict.
     * KF493 distinguishes these from the expected-token and unexpected-token classes owned by
     * [CONDITION_GRAMMAR]; the family selects a verdict rather than inferring one from trailing tokens.
     */
    CONDITION_COMPLETENESS,

    /**
     * Mixed `And`/`Or` at a completed connective site, which A12 refuses without precedence.
     * Recognition supplies independent frames for bracket pairs and filter conditions; report execution
     * selects only reached sites (KF499), including sites completed before a later syntax failure.
     */
    CONNECTIVE_AGREEMENT,

    /**
     * Unexpected-token and expected-token failures from the syntax verdict, including typed operator
     * arguments and arity. KF493 supplies the classification contract; [CONDITION_COMPLETENESS]
     * selects its distinct incomplete-input class from the same recognition result.
     */
    CONDITION_GRAMMAR,

    /**
     * What a temporal extractor demands of the date it reads once the date slot has admitted it. One constant
     * for the three classes because `CheckDatumExtractOpImpl.check` asks them in a fixed order over one
     * operand, and the two date-yielding extractors ask the format question alone (KF529).
     */
    TEMPORAL_EXTRACTOR_OPERANDS,

    /**
     * A12's basic sentences: an empty id, name, condition, error target, computed field or operation, a repeated
     * enumeration value or category, an empty type reference; a missing condition or operation counts as empty
     * ([KF643]). A12 states them over the model as read, after every other check and through any variant filter
     * ([KF626]), except where the defect also fails its build: those A12 states only once a filter removes the
     * declaration, and beside a kept, unbuilt model the checker adds the sentence of its own accord.
     */
    BASIC_SENTENCES,

    /**
     * What `DateTime(date, time)` demands of its two operands: a dated Date with a year or a Base Year and no
     * clock, fully known where it is a field, then a pure-clock Time. Its own constant because
     * `CheckDateTimeKonstruktImpl` is a checker of its own, asking the Date operand before the Time one ([KF627]).
     */
    DATE_TIME_CONSTRUCTION_OPERANDS,
}

/**
 * A portion of the input that could not be examined, and why.
 *
 * There is deliberately no "which family" field. A gap is not one-to-one with a family — an unexpanded
 * mount blocks both reference families at once, and the unread declared members limit one without stopping
 * it — so a single slot could only ever be filled by guessing. [ConsistencyReport.checksCompleted] already
 * says which families ran; [reason] says what this particular gap costs.
 *
 * @param at the declaration it concerns, absent when the gap is the whole analysis.
 */
data class CoverageGap(val at: String?, val reason: String)

/**
 * What a consistency check produced.
 *
 * [findings] and [diagnostics] are deliberately separate: a finding is A12's verdict on a declaration, a
 * diagnostic is the checker saying it could not read something. Folding them together is the conflation
 * `ModelLoader.loadAndCheck` makes on the Java side, where an unreadable source arrives on the same channel
 * as an invalid declaration and a caller cannot tell them apart.
 *
 * @param modelId the source's own `header.id`, absent when admission could not read one.
 * @param checksCompleted the families that ran to completion — evidence, not a claim of sufficiency.
 */
data class ConsistencyReport(
    val modelId: String?,
    val status: ConsistencyStatus,
    val findings: List<Finding>,
    val diagnostics: List<Diagnostic>,
    val checksCompleted: Set<CheckFamily>,
    val gaps: List<CoverageGap>,
)

/**
 * Check one model source.
 *
 * The result can be INVALID or INCONCLUSIVE and never VALID, because no evidence exists that the pinned
 * profile's required checks ran — only that the one implemented family did. That bar lifts with the coverage
 * registry, not with an added enum constant (PORTABLE-CONSISTENCY-PROPOSAL §7, "the first one-check slice
 * cannot emit VALID by construction").
 *
 * An unreadable source yields a report rather than a raised exception, with its failure stated at the source
 * level rather than attributed to a rule that was never read.
 */
fun check(source: ModelSource): ConsistencyReport {
    val admitted = when (val admission = admit(source)) {
        is Admission.Rejected -> return ConsistencyReport(
            modelId = null,
            status = ConsistencyStatus.Inconclusive,
            findings = emptyList(),
            diagnostics = listOf(admission.diagnostic),
            checksCompleted = emptySet(),
            gaps = listOf(CoverageGap(null, "the source could not be admitted, so nothing was checked")),
        )
        is Admission.Admitted -> admission
    }
    return check(admitted, providers = emptyMap(), inherited = emptyList())
}

/**
 * Check one already-admitted entry model against the [providers] its includes may name.
 *
 * [inherited] are diagnostics the caller already holds about the source set itself — a source that could not
 * be admitted, an id supplied twice. They ride into the report because they are usually the CAUSE of a mount
 * this analysis then reports as unexpanded, and a consumer shown only the consequence cannot act on it.
 */
internal fun check(
    admitted: Admission.Admitted,
    providers: Map<String, Admission.Admitted>,
    inherited: List<Diagnostic>,
): ConsistencyReport = checkPrepared(prepare(admitted, providers), admitted.modelId, inherited)

/**
 * Check an already-prepared fact base — the seam a caller needs when the thing to check is not a source.
 *
 * It exists for the draft path: text an editor is typing is not in any source yet, so applying it to the fact
 * base and checking THAT is the only way to answer without writing the model first ([checkDraft]). The source
 * path reaches it through [check] and nothing else changes — preparation is still where a fact base comes
 * from, and this function makes no decision preparation used to make.
 */
internal fun checkPrepared(
    prepared: PreparedModel,
    modelId: String?,
    inherited: List<Diagnostic>,
): ConsistencyReport = checkRun(prepared, modelId, inherited, CheckCells.NONE, CellRetention.DISCARDED).report

/**
 * Whether a check must leave a store a LATER check can answer from.
 *
 * **A parameter rather than something read off `carried`, because the two are independent.** Making a
 * snapshot carries nothing and keeps everything; [checkPrepared] carries nothing and keeps nothing; a drafted
 * edit carries a store and keeps the next one. Only the caller knows which it is.
 *
 * **What `DISCARDED` buys, measured.** Recording each fact a family reads and capturing each read's value is
 * ~180 ms of a 509 ms 200-program check, and the stateless path throws the result away the instant it has the
 * report. Nothing else consumes a recorded read — `CheckCells.cellFor` is the only main-source reader of the
 * transcript — so skipping it cannot change a verdict, which `CellRetentionTest` locks by comparing the two
 * runs' reports rather than by matching a recorded expectation.
 */
internal enum class CellRetention {
    /** Record the reads and keep the store: a snapshot will be asked again. */
    KEPT,

    /** Record nothing and hand back [CheckCells.NONE]: this report is the whole answer. */
    DISCARDED,
}

/**
 * The same check, plus the per-family cells a LATER check over a nearby model can answer from.
 *
 * Separate from [checkPrepared] rather than replacing it because the cells are of no use to a caller that
 * will not ask again: every other call site wants the report and nothing else, and threading a store through
 * them would put an unused parameter on the checker's own seam.
 *
 * @param carried cells from an earlier check, [CheckCells.NONE] for a first one. A cell is used only when
 *     every fact it recorded still holds the same value in [prepared], so passing cells from an unrelated
 *     model costs work and cannot change an answer.
 */
internal fun checkRun(
    prepared: PreparedModel,
    modelId: String?,
    inherited: List<Diagnostic>,
    carried: CheckCells,
    retention: CellRetention,
): CheckRun {
    prepared.unsupportedConditionLanguage?.let { code ->
        // A12 refuses the model rather than falling back to a language, so there is no reading of its
        // conditions to have — every keyword question would be answered in a language A12 never applies.
        return unexamined(ConsistencyReport(
            modelId = modelId,
            status = ConsistencyStatus.Invalid,
            findings = listOf(
                Finding(
                    FindingCategory.A12_CONSTRAINT,
                    FindingSeverity.ERROR,
                    CK_MODEL_NOT_BUILDABLE,
                    "`$code` is not a condition language A12 supports, so the model cannot be used at all",
                ),
            ),
            diagnostics = inherited + prepared.diagnostics,
            checksCompleted = emptySet(),
            gaps = prepared.gaps() + UNIMPLEMENTED_FAMILIES,
        ))
    }
    val unmounted = prepared.unexpandedMounts.map {
        CoverageGap(
            at = it.at,
            reason = "this group mounts `${it.alias}` and the mount is not expanded here (${it.reason}), so " +
                "the fact base is incomplete and no reference check can run over this source",
        )
    }
    if (prepared.reachedModelRefusals.isNotEmpty()) {
        // A12 reads every model the entry reaches before it builds or checks the entry (KF594), so a refusal raised
        // there leaves no model whose references or declarations any family could judge as A12 would.
        return unexamined(ConsistencyReport(
            modelId = modelId,
            status = ConsistencyStatus.Invalid,
            findings = prepared.reachedModelRefusals.map { refusal ->
                Finding(
                    FindingCategory.A12_CONSTRAINT,
                    FindingSeverity.ERROR,
                    CK_MODEL_NOT_BUILDABLE,
                    refusal,
                )
            },
            diagnostics = inherited + prepared.diagnostics,
            checksCompleted = emptySet(),
            gaps = prepared.gaps() + unmounted + UNIMPLEMENTED_FAMILIES,
        ))
    }
    if (unmounted.isNotEmpty()) {
        // The fact base is INCOMPLETE, so "no declared element matches" is not a verdict this checker may
        // reach: the elements are declared, in a model this source does not carry. Reporting the references
        // anyway would reject a model A12 accepts, which is the one direction a checker must never take.
        return unexamined(ConsistencyReport(
            modelId = modelId,
            status = ConsistencyStatus.Inconclusive,
            findings = emptyList(),
            diagnostics = inherited + prepared.diagnostics,
            checksCompleted = emptySet(),
            gaps = prepared.gaps() + unmounted + UNIMPLEMENTED_FAMILIES,
        ))
    }
    // What a migrated family receives instead of the fact base itself, so that it cannot read a fact without
    // the read being observable — the barrier's whole purpose, and a type rather than a lint because an
    // untracked read then does not compile. One transcript per check, shared by every migrated family: a read
    // is a property of the model, not of the family that happened to make it.
    val tracked = TrackedFactBase(prepared, ReadTranscript(retention))
    val execution = executeChecks(tracked, prepared, carried)
    val scheduled = execution.scheduled
    val cells = execution.cells
    val reused = execution.reused
    val findings = execution.reportFindings(tracked)
    return CheckRun(
        report = ConsistencyReport(
            modelId = modelId,
            status = statusOf(findings),
            findings = findings,
            diagnostics = inherited + prepared.diagnostics,
            // The two the composition produced above, then everything the SCHEDULE ran. Derived rather than
            // listed: a family wired into the report while this set stayed silent about it was a live
            // possibility, and the wiring guard could only catch the opposite direction.
            //
            // From `scheduled` rather than from [CHECK_PRODUCERS], corrected 2026-09-18: a per-declaration
            // producer is asked once per DECLARATION, so on a source that declares no elements it runs zero
            // times while the registry still lists it. The report already discloses that state as a gap, so
            // the over-claim was reachable, and `checksCompleted` is evidence — it may not offer a family
            // that never ran (`ChecksCompletedScopeTest`). Whenever anything is declared the two derivations
            // are the same set, which that test's populated row is the control for.
            checksCompleted = COMPOSED_FAMILIES + scheduled.flatMap { it.key.producer.completes },
            gaps = prepared.gaps() + prepared.emptyFactBase() + findings.buildBlocked() +
                scheduled.flatMap { cells.getValue(it.key).gaps } + UNREAD_MEMBERS +
                UNIMPLEMENTED_FAMILIES,
        ),
        cells = when (retention) {
            CellRetention.KEPT -> CheckCells(cells)
            CellRetention.DISCARDED -> CheckCells.NONE
        },
        families = FamilyReuse(reused = reused, recomputed = scheduled.size - reused),
    )
}

/**
 * One check's report, and what a later check over a nearby model may answer from.
 *
 * @param families what this check reused from [checkRun]'s `carried` store — MEASURED from the decisions the
 *     store actually made, so an implementation that revalidated nothing reports every family recomputed.
 */
internal class CheckRun(
    val report: ConsistencyReport,
    val cells: CheckCells,
    val families: FamilyReuse,
)

/** A model nothing was examined in: a report, no cells to carry, and no family work to have reused. */
private fun unexamined(report: ConsistencyReport) = CheckRun(report, CheckCells.NONE, FamilyReuse.NONE)

/**
 * A source that declares nothing produces a report indistinguishable from one whose references all resolve,
 * so it says which of the two it is.
 *
 * This is a GAP and not a rejection because A12 accepts such a model: a type-def-only library is exactly an
 * empty root and is Kernel-valid standalone, and the Kernel reads an absent `rootGroups` and an absent
 * `modelRoot` too (measured 2026-09-12, `ModelRootReadabilityLawsTest`). The one shape it cannot read —
 * a missing `content` — is refused a phase earlier, at admission.
 */
private fun PreparedModel.emptyFactBase(): List<CoverageGap> = if (elements.isNotEmpty()) {
    emptyList()
} else {
    listOf(
        CoverageGap(
            at = null,
            reason = "this source declares no elements, so no rule or computation was examined — a report " +
                "with no findings here means nothing was found to check, not that nothing was wrong",
        ),
    )
}

/**
 * A model's `content.typeDefinitions` declare field types that only the constant index-key path examines here.
 *
 * Preparation retains their ids and unambiguous bodies so a `TypeDefType` reference and a String index key
 * can be judged — but each definition produces no element, and the enum, character and range-pair families are all
 * keyed on a field's inline `fieldType`. The carrier is visibly in scope elsewhere in the same report, which
 * is exactly why its absence here has to be said rather than inferred.
 */
internal fun TrackedFactBase.typeDefinitionBodyGaps(): List<CoverageGap> = if (declaredTypeDefinitionIds.isEmpty()) {
    emptyList()
} else {
    listOf(
        CoverageGap(
            at = null,
            reason = "this model declares ${declaredTypeDefinitionIds.size} type definition(s) under " +
                "`content.typeDefinitions`; only an unambiguous String definition used as an index key " +
                "was examined here, so other laws this checker applies to an inline `fieldType` were not " +
                "applied inside the definitions",
        ),
    )
}

/** A declaration the checker could not read was not checked either, so each one is also a coverage gap. */
private fun PreparedModel.gaps(): List<CoverageGap> = diagnostics.map {
    CoverageGap(it.at, "this declaration could not be read, so no check ran over it: ${it.explain}")
}

/**
 * The findings that stop A12 from producing a verdict at all, so every OTHER finding in the same report is
 * this checker's own reading rather than something A12 would have said about this model.
 *
 * They are recognized by their code, because the class is wider than any one family: an unresolvable
 * computed field and a target climbing past the root stop the Kernel from BUILDING the model (measured
 * through `ModelLoader.loadAndCheck`), while a message entry or a locale code its READER refuses stops it
 * one tier earlier still. A consumer told only the findings would assume the list is A12's; the gap says
 * which it is.
 */
private fun List<Finding>.buildBlocked(): List<CoverageGap> =
    filter { it.code == CK_MODEL_NOT_BUILDABLE }.map {
        CoverageGap(
            at = it.at,
            reason = "this makes the model unusable, so A12 reports that and stops; every other finding " +
                "here is this checker's own reading of a model A12 never got far enough to judge",
        )
    }

/**
 * What this checker reads only PART of, and the one law it reads fully and deliberately does not reproduce.
 *
 * Stated on every report rather than only in the plan, because a consumer cannot otherwise tell a clean
 * result from an unexamined one. An entry earns its place by naming what would settle it, so a later session
 * can close it rather than rediscover why it is open.
 */
private val UNREAD_MEMBERS = listOf(
    CoverageGap(
        at = null,
        reason = "a field type's body is judged on the member A12 constructs from and on the two CONTENT " +
            "laws measured beyond it — a `DateRangeType`'s (format, separator) pair, and an " +
            "`EnumerationType`'s values against its categories. What a member otherwise holds is left to " +
            "A12: a declared `format` is reported refused only when the probed universe holds it, so one " +
            "outside that universe, which A12 refuses too, is left to it, since the admitted set is " +
            "explicitly not closed; a `CustomFieldType`'s `name` is judged on presence alone, " +
            "and A12 refuses a no-break-space name in prose with no class this checker could cite",
    ),
    CoverageGap(
        at = null,
        reason = "A12 refuses a character outside the Basic Multilingual Plane in every text it validates as " +
            "part of the model, with no class; this checker judges the carriers measured for it (a rule's " +
            "and a computation's texts, a field's and a group's annotations, enum values and labels, a " +
            "field type's own message, every element's path) and leaves the rest to A12 — a field type's " +
            "other members, a category, the header, and a mounted provider's declarations",
    ),
    CoverageGap(
        at = null,
        reason = "a rule's `errorCode` is judged on presence alone. A12's content law — \"only letters, " +
            "digits, blanks and underscores\" — states its verdict in prose with no class this checker could " +
            "cite, and which characters it counts as letters rests on a handful of rows " +
            "(KERNEL-FINDINGS KF310), so a code such as `A-B` is left to A12. Re-open when this checker " +
            "owns a code of its own for it",
    ),
    CoverageGap(
        at = null,
        reason = "two entity filters sharing ONE argument list are treated as separate connective levels " +
            "without a measurement saying they are — `SumOfProducts` is the only operator whose argument " +
            "list takes two entity specs and it refuses a filter on either for a reason of its own, so no " +
            "oracle for that shape exists. This is silence rather than a wrong verdict",
    ),
    // A measured law deliberately not reproduced, and the reason is what a consumer needs rather than the
    // omission: both of A12's pre-emptions here are decidable only with machinery this checker does not
    // have, so reproducing the law would state a class A12 did not issue on two shapes out of three.
    CoverageGap(
        at = null,
        reason = "a computation that READS its own computed field is refused by A12 and is not reported " +
            "here: a projected read draws a different class than a plain one, and a derived-scale mismatch " +
            "in the same operation pre-empts both — neither is decidable without inferring an operation's " +
            "scale, which this checker does not do. Re-open when it can",
    ),
)

private val UNIMPLEMENTED_FAMILIES = listOf(
    CoverageGap(
        at = null,
        reason = "only the families named by `CheckFamily` are implemented; every other required family of " +
            "the pinned profile was not examined",
    ),
)
