package io.github.mbackschat.a12.dm.consistency

import io.github.mbackschat.a12.dm.consistency.syntax.CallOperand
import io.github.mbackschat.a12.dm.consistency.syntax.ConditionCall
import io.github.mbackschat.a12.dm.consistency.syntax.OPERATOR_SPELLINGS
import io.github.mbackschat.a12.dm.consistency.syntax.OUTER_MARKER
import io.github.mbackschat.a12.dm.consistency.syntax.OperatorId
import io.github.mbackschat.a12.dm.consistency.syntax.capturedPath

/**
 * A group-list quantifier that names the same group twice, or names a group and something under it.
 *
 * A12 refuses both, with two different codes: `MVK_DUPLICATE_PARAM1` for the same group twice and
 * `MVK_DUPLICATE_PARAM2` when one operand CONTAINS another ([KERNEL-FINDINGS KF325],
 * `rulekit.validate.laws.GroupListDuplicateReachLawsTest`). Both classes hold on all six carriers that take
 * a group list, and neither depends on where the error field sits.
 *
 * **The gate reads ONE CALL's operand list, which is why this family parses rather than scans.** The same
 * group named once in each of two calls is admitted, and no reading of a condition's flat set of names can
 * tell that from a group named twice in one. That is the capability [callsIn] exists for.
 *
 * **Identity is the RESOLVED element, and containment is by path STEP.** A relative spelling beside the
 * absolute spelling of the same group is an exact duplicate, so comparing authored text would miss it; and
 * `Garage` does not contain `GarageBay`, so comparing text prefixes would refuse a model A12 admits. Both
 * rows are measured.
 *
 * **The two arms key an operand differently, and both differences are measured.** The exact arm skips a
 * STARRED operand — one repeatable group named twice with its wildcard is ADMITTED — and counts the `$`
 * capture marker, so a group beside its own capture repeats nothing. The nested arm does neither: a starred
 * group contains its starred subgroup, and a group contains its captured descendant in either direction
 * (`adapter.laws.CheckerOverlapIdentityAgreementTest`; `EntityRef.equals` against
 * `CheckEntityListenUtils.isEntityIndirectlyReferenced` in Kernel 30.8.1). *Corrected 2026-10-09:* this family
 * left starred and captured operands out of both arms, and so was silent on both nested rows.
 *
 * **Two shapes leave it silent.** An operand that does not RESOLVE pre-empts the gate, A12 reporting the
 * entity and nothing about the duplicate, so reporting here would name two fixes for one typo. And an operand
 * this reader cannot reduce to one path — a nested call, an expression, a filtered reference — is compared
 * against nothing.
 *
 * **One more silence, and it is the price of parsing.** A12's duplicate gate runs before BOTH syntax phases:
 * a duplicate inside an ungrammatical or unlexable condition draws the duplicate class where the same text
 * without the duplicate draws the parse or lexer code. [callsIn] yields nothing for text it cannot parse, so
 * this family says nothing there — an under-report, bounded by the two families that already report the
 * syntax defect, and the alternative is reading an argument list out of tokens A12's own lexer never saw.
 *
 * **The boundary: only the group list.** A12 draws the same two codes on field lists and value lists, and
 * that is a different measurement on a different carrier; nothing here is claimed about them.
 *
 * ## …and a ROOT group where the carrier does not admit one
 *
 * The same operand list carries a second law with two more codes, and it is evaluated here because the two
 * are ORDERED: a root beside its own descendant is an overlap, and A12 reports the overlap
 * ([KERNEL-FINDINGS KF326], `rulekit.validate.laws.GroupListRootOperandLawsTest`).
 *
 * **The carriers split, and not the way their names suggest.** `AllGroupsFilled`, `NotAllGroupsFilled` and
 * `GroupsNotCollectivelyFilled` refuse a root operand outright with `MVK_ROOT_GROUP_REFERENCED`, even as the
 * sole operand; `AtLeastOneGroupFilled`, `NoGroupFilled` and `NumberOfFilledGroups` admit a SOLE root and
 * refuse one beside any other operand with `MVK_ROOT_GROUP_WITH_OTHER_PARAMETERS`.
 *
 * **A STARRED root is NOT exempt**, which is the asymmetry against the duplicate gate above: the wildcard
 * takes an operand out of the duplicate comparison and leaves it fully inside this one.
 *
 * **An operand A12 refuses while reading it silences every gate here**, the duplicate and kind gates as well
 * as the root one. An unstarred repeatable co-operand read from outside its group draws its wildcard or
 * containment class ALONE, and the root class appears only once the read passes, as it does from inside
 * ([anOperandIsRefusedOnRead]). *Corrected 2026-09-25:* this said the root violation "holds in both" and
 * that the family needed no iteration analysis, so it named the root class beside the one A12 gives.
 *
 * ## …and a FIELD on the three carriers that refuse one
 *
 * A third law, on a different and SMALLER carrier set, which is the whole of its content: the five group-list
 * QUANTIFIERS admit a field operand, and only `NumberOfFilledGroups` and the two scalars `GroupFilled` and
 * `GroupNotFilled` refuse one with `MVK_NO_FIELDS_ALLOWED` ([KERNEL-FINDINGS KF327],
 * `rulekit.validate.laws.GroupListOperandKindLawsTest`). A family assembled from the code's NAME — "group
 * predicates take groups only" — would refuse five legal shapes, which is why the carrier set is measured
 * rather than derived from what the operators are called.
 *
 * On those three carriers the kind gate runs LAST of the gates this file judges and outruns only the arity
 * class, which is A12's order and is not reproduced by accident: the checks below are written in it.
 */
internal fun TrackedFactBase.groupListOperandFindings(): List<Finding> = declarations().flatMap { element ->
    groupListContributions(element).map { it.finding }
}

internal fun TrackedFactBase.groupListContributions(
    element: TrackedDeclaration,
    execution: ConditionExecution? = conditionExecution(element),
): List<ConditionFinding> {
    val judged = spelled(GROUP_LIST_OPERATORS) + spelled(FIELD_REFUSING_OPERATORS)
    val group = element.path.substringBeforeLast('/', missingDelimiterValue = "")
    return callContributions(element, execution) { member, call ->
        if (call.operator in judged) operandFinding(call, group, element, member) else null
    }
}

/** The one group-list carrier that refuses a keyed operand. */
private val GROUP_COUNT = OperatorId.NUMBER_OF_FILLED_GROUPS

/** The six operators whose argument list is a list of GROUPS, named by their catalog ids. */
private val GROUP_LIST_OPERATORS = setOf(
    OperatorId.ALL_GROUPS_FILLED,
    OperatorId.NOT_ALL_GROUPS_FILLED,
    OperatorId.GROUPS_NOT_COLLECTIVELY_FILLED,
    OperatorId.AT_LEAST_ONE_GROUP_FILLED,
    OperatorId.NO_GROUP_FILLED,
    GROUP_COUNT,
)

/** …and the three that refuse a FIELD operand, which is not the same set and not a subset of one law's. */
private val FIELD_REFUSING_OPERATORS = setOf(GROUP_COUNT, OperatorId.GROUP_FILLED, OperatorId.GROUP_NOT_FILLED)

/** The three carriers that admit a root as the list's SOLE operand. */
private val SOLE_ROOT_CARRIERS = setOf(OperatorId.AT_LEAST_ONE_GROUP_FILLED, OperatorId.NO_GROUP_FILLED, GROUP_COUNT)

/** How this model's language spells each of [ids]; an id the catalog does not carry contributes nothing. */
private fun TrackedFactBase.spelled(ids: Set<OperatorId>): Set<String> =
    ids.mapNotNull { OPERATOR_SPELLINGS[conditionLanguage]?.get(it) }.toSet()

private fun TrackedFactBase.operandFinding(
    call: ConditionCall,
    declaringGroup: String,
    element: TrackedDeclaration,
    member: String,
): Finding? {
    // `NumberOfFilledGroups` asks its category gate before it builds the list ([entityListCategoryFindings]).
    if (categoryGateAnswersBeforeTheList(call, declaringGroup, element)) {
        return null
    }
    val bound = call.operands.map { it to it.resolvedBy(this, declaringGroup, element.origin) }
    val captures = call.operands.map { it.capturedPath(conditionLanguage) }
    val captured = call.operands.zip(captures) { operand, path ->
        operand to path?.let { resolveEntity(declaringGroup, it, element.origin) }
    }
    // A12 reports the entity and says nothing about the duplicate, so this family has nothing to add.
    if ((bound + captured).any { (operand, reference) -> reference != null && reference !is Reference.Resolved }) {
        return null
    }
    // Every gate below is the operator's own, and A12 asks none of them once reading an operand has failed.
    if (anOperandIsRefusedOnRead(call, element)) {
        return null
    }
    val resolved = bound.mapNotNull { (_, reference) -> (reference as? Reference.Resolved)?.path }
    if (call.operator !in spelled(GROUP_LIST_OPERATORS)) {
        return kindFinding(call, resolved, member, element.path)
    }
    val nested = bound.indices.mapNotNull { i ->
        ((bound[i].second ?: captured[i].second) as? Reference.Resolved)?.path?.let { path -> path to i }
    }
    // A starred operand is outside the exact arm — the measured row is `NumberOfFilledGroups(G*, G*)`, which
    // A12 ADMITS — and a capture is a different operand from the same path uncaptured.
    val comparable = nested.mapNotNull { (path, i) ->
        val capture = captures[i]
        when {
            call.operands[i].path?.contains('*') == true || capture?.contains('*') == true -> null
            capture != null -> "\$$path"
            else -> path
        }
    }
    // A keyed operand is its path AND its key (kf439), so the same group under the same key repeats: `Legs For
    // "X"` twice is `MVK_DUPLICATE_PARAM1` (`rulekit.validate.laws.SemanticIndexPinnedLevelLawsTest`). How keyed
    // operands overlap is unmeasured, so they meet only the exact comparison.
    val keyed = call.operands.mapNotNull { keyedIdentityOf(it, call.inAFilterBody, declaringGroup, element) }
    // The exact duplicate wins over an overlap in the same call whatever the authored order, as A12 does.
    exactDuplicate(comparable + keyed)?.let { repeated ->
        return finding(
            "MVK_DUPLICATE_PARAM1",
            "this $member names `$repeated` twice in one `${call.operator}` — A12 refuses a group list that " +
                "repeats an operand, whichever way each occurrence is spelled",
            element.path,
            call.spanIn(member),
        )
    }
    overlap(nested.map { it.first })?.let { (outer, inner) ->
        return finding(
            "MVK_DUPLICATE_PARAM2",
            "this $member names `$outer` and `$inner` in one `${call.operator}`, and the second lies under " +
                "the first — A12 refuses a group list whose operands contain one another",
            element.path,
            call.spanIn(member),
        )
    }
    // The root law runs after both duplicate classes because they pre-empt it, measured on a root beside its
    // own descendant. A starred root still counts here, unlike in the comparisons above.
    return rootFinding(call, resolved, member, element.path)
        ?: semanticIndexFinding(call, member, element.path)
        ?: kindFinding(call, resolved, member, element.path)
}

/**
 * The keyed-operand finding for `NumberOfFilledGroups`, which counts whole groups and asks `checkNoSemanticIndex`
 * between its root and field gates (source-read, [KERNEL-FINDINGS KF612]). Any written index counts, starred
 * value or not: a key the index chain refuses is reported at its own site, which closes before this call.
 */
private fun TrackedFactBase.semanticIndexFinding(call: ConditionCall, member: String, at: String): Finding? {
    if (call.operator != OPERATOR_SPELLINGS[conditionLanguage]?.get(GROUP_COUNT)) return null
    val selected = call.operands.firstOrNull { writesASemanticIndex(it.text) }?.text?.javaTrimmed() ?: return null
    return finding(
        "MVK_SEMANTIC_INDEX_NOT_ALLOWED",
        "this $member hands `${call.operator}` the selection `$selected`, and a group count takes whole groups — " +
            "drop the key, or count the selected row's fields instead",
        at,
        call.spanIn(member),
    )
}

/**
 * The field-operand finding for this call, or null when the carrier takes a field.
 *
 * The carrier set is the whole law: five group-list quantifiers ADMIT a field operand and only these three
 * refuse one, so widening it by analogy with the operators' names would refuse five shapes A12 takes.
 */
private fun TrackedFactBase.kindFinding(
    call: ConditionCall,
    resolved: List<String>,
    member: String,
    at: String,
): Finding? {
    if (call.operator !in spelled(FIELD_REFUSING_OPERATORS)) {
        return null
    }
    val field = resolved.firstOrNull { isField(it) } ?: return null
    return finding(
        "MVK_NO_FIELDS_ALLOWED",
        "this $member hands the field `$field` to `${call.operator}`, which takes groups — name the group " +
            "it sits in, or use the field-shaped operator instead",
        at,
        call.spanIn(member),
    )
}

/**
 * The root-operand finding for this call, or null when the carrier admits the root it names.
 *
 * The arity half counts the AUTHORED operands rather than the resolved ones: "a root beside another operand"
 * is a fact about the list, and an operand this reader could not reduce to a path is still an operand.
 */
private fun TrackedFactBase.rootFinding(
    call: ConditionCall,
    resolved: List<String>,
    member: String,
    at: String,
): Finding? {
    val root = resolved.firstOrNull { path -> path.isRootGroup() && isGroup(path) } ?: return null
    return when {
        call.operator in soleRootCarriers() && call.operands.size < 2 -> null
        call.operator in soleRootCarriers() -> finding(
            "MVK_ROOT_GROUP_WITH_OTHER_PARAMETERS",
            "this $member names the root group `$root` beside another operand in one `${call.operator}` — " +
                "A12 admits a root there only as the list's sole operand",
            at,
            call.spanIn(member),
        )
        else -> finding(
            "MVK_ROOT_GROUP_REFERENCED",
            "this $member names the root group `$root` in one `${call.operator}`, which takes no root " +
                "operand at all — name the groups beneath it instead",
            at,
            call.spanIn(member),
        )
    }
}

private fun TrackedFactBase.soleRootCarriers(): Set<String> = spelled(SOLE_ROOT_CARRIERS)

private fun TrackedFactBase.isGroup(path: String): Boolean = declares(path, DeclaredKind.GROUP)

private fun TrackedFactBase.isField(path: String): Boolean = declares(path, DeclaredKind.FIELD)

private fun TrackedFactBase.declares(path: String, kind: DeclaredKind): Boolean =
    declarationAt(path, kind) != null

private fun CallOperand.resolvedBy(
    model: TrackedFactBase,
    declaringGroup: String,
    origin: DeclarationOrigin,
): Reference? = path?.let { model.resolveEntity(declaringGroup, it, origin) }

/**
 * The group [operand] reads under a key the index chain admits, spelled with that key and with its `$` capture
 * marker, or null. The marker is part of A12's exact identity here too: a captured selection repeated in one list
 * is the duplicate class, which A12 raises while parsing and so ahead of the whole-rule refusal of any index in a
 * filter body (`adapter.laws.CheckerPostParseOrderAgreementTest`).
 */
private fun TrackedFactBase.keyedIdentityOf(
    operand: CallOperand,
    inAFilterBody: Boolean,
    declaringGroup: String,
    element: TrackedDeclaration,
): String? {
    val written = operand.text.javaTrimmedStart()
    val captured = written.startsWith(OUTER_MARKER)
    val text = if (captured) written.removePrefix(OUTER_MARKER).javaTrimmedStart() else operand.text
    // A starred selection is outside the exact arm, as a starred unkeyed operand is above.
    val read = operandReferenceIn(text, declaringGroup, element, inAFilterBody) { null }
        ?.takeIf { it.indexSelected && '*' !in it.reference } ?: return null
    val path = (resolveEntity(declaringGroup, read.reference, element.origin) as? Reference.Resolved)?.path
        ?: return null
    return (if (captured) OUTER_MARKER else "") + "$path For ${read.key}"
}

/** Every gate here is the operator's own, raised once its call is read, so each spans the call. */
private fun finding(code: String, explain: String, at: String, span: TextSpan) =
    Finding(FindingCategory.A12_CONSTRAINT, FindingSeverity.ERROR, code, explain, at, span)

/** The element the list names twice, in authored order — one name, since both occurrences resolve to it. */
private fun exactDuplicate(paths: List<String>): String? = paths.firstPair { a, b -> a == b }?.first

/** The first pair where one operand lies under the other, outer first — by path STEP, never by text. */
private fun overlap(paths: List<String>): Pair<String, String>? =
    paths.firstPair { a, b -> b.startsWith("$a/") || a.startsWith("$b/") }
        ?.let { (a, b) -> if (b.startsWith("$a/")) a to b else b to a }

private inline fun List<String>.firstPair(related: (String, String) -> Boolean): Pair<String, String>? {
    indices.forEach { i ->
        (i + 1..lastIndex).forEach { j ->
            if (related(this[i], this[j])) {
                return this[i] to this[j]
            }
        }
    }
    return null
}
